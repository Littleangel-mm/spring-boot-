-- 创建数据库
CREATE DATABASE IF NOT EXISTS treehole DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE treehole;

-- 用户表
CREATE TABLE IF NOT EXISTS t_user (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID',
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(255) NOT NULL COMMENT '密码',
    real_name VARCHAR(50) COMMENT '真实姓名',
    phone VARCHAR(20) COMMENT '手机号',
    email VARCHAR(100) COMMENT '邮箱',
    avatar VARCHAR(200) COMMENT '头像',
    introduction VARCHAR(500) COMMENT '个人简介',
    role VARCHAR(20) NOT NULL COMMENT '用户角色：ADMIN-管理员，STUDENT-学生，TEACHER-心理老师',
    enabled BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否启用',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间'
) COMMENT='用户表';

-- 心理资讯表（提前创建以便后续外键引用）
CREATE TABLE IF NOT EXISTS t_psych_info (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '心理资讯ID',
    title VARCHAR(100) NOT NULL COMMENT '标题',
    content TEXT NOT NULL COMMENT '内容',
    cover_image VARCHAR(200) COMMENT '封面图片',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    view_count INT NOT NULL DEFAULT 0 COMMENT '浏览量',
    is_top BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否置顶',
    status BOOLEAN NOT NULL DEFAULT TRUE COMMENT '状态：发布/草稿',
    approved BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否审核通过',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    publish_time DATETIME DEFAULT NULL COMMENT '发布时间',
    FOREIGN KEY (user_id) REFERENCES t_user(id)
) COMMENT='心理资讯表';

-- 文章分类表
CREATE TABLE IF NOT EXISTS t_category (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '分类ID',
    name VARCHAR(50) NOT NULL UNIQUE COMMENT '分类名称',
    description VARCHAR(200) COMMENT '分类描述',
    sort INT NOT NULL DEFAULT 0 COMMENT '排序',
    enabled BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否启用',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间'
) COMMENT='文章分类表';

-- 文章表
CREATE TABLE IF NOT EXISTS t_article (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '文章ID',
    title VARCHAR(100) NOT NULL COMMENT '文章标题',
    content TEXT NOT NULL COMMENT '文章内容',
    cover_image VARCHAR(200) COMMENT '封面图片',
    view_count INT NOT NULL DEFAULT 0 COMMENT '浏览量',
    like_count INT NOT NULL DEFAULT 0 COMMENT '点赞量',
    comment_count INT NOT NULL DEFAULT 0 COMMENT '评论数',
    is_top BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否置顶',
    is_recommend BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否推荐',
    status BOOLEAN NOT NULL DEFAULT TRUE COMMENT '状态：发布/草稿',
    category_id BIGINT NOT NULL COMMENT '所属分类ID',
    author_id BIGINT NOT NULL COMMENT '作者ID',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    publish_time DATETIME DEFAULT NULL COMMENT '发布时间',
    FOREIGN KEY (category_id) REFERENCES t_category(id),
    FOREIGN KEY (author_id) REFERENCES t_user(id)
) COMMENT='文章表';

-- 分区表
CREATE TABLE IF NOT EXISTS t_zone (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '分区ID',
    name VARCHAR(50) NOT NULL UNIQUE COMMENT '分区名称',
    description VARCHAR(200) COMMENT '分区描述',
    icon VARCHAR(200) COMMENT '分区图标',
    sort INT NOT NULL DEFAULT 0 COMMENT '排序',
    enabled BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否启用',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间'
) COMMENT='分区表';

-- 帖子表
CREATE TABLE IF NOT EXISTS t_post (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '帖子ID',
    title VARCHAR(100) NOT NULL COMMENT '帖子标题',
    content TEXT NOT NULL COMMENT '帖子内容',
    user_id BIGINT NOT NULL COMMENT '发帖用户ID',
    zone_id BIGINT NOT NULL COMMENT '所属分区ID',
    view_count INT NOT NULL DEFAULT 0 COMMENT '浏览量',
    like_count INT NOT NULL DEFAULT 0 COMMENT '点赞量',
    comment_count INT NOT NULL DEFAULT 0 COMMENT '评论数',
    is_top BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否置顶',
    is_essence BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否精华',
    is_anonymous BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否匿名',
    status BOOLEAN NOT NULL DEFAULT TRUE COMMENT '状态：正常/禁用',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    FOREIGN KEY (user_id) REFERENCES t_user(id),
    FOREIGN KEY (zone_id) REFERENCES t_zone(id)
) COMMENT='帖子表';

-- 评论表
CREATE TABLE IF NOT EXISTS t_comment (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '评论ID',
    content TEXT NOT NULL COMMENT '评论内容',
    article_id BIGINT DEFAULT NULL COMMENT '所属文章ID',
    post_id BIGINT DEFAULT NULL COMMENT '所属帖子ID',
    user_id BIGINT NOT NULL COMMENT '评论用户ID',
    parent_id BIGINT DEFAULT NULL COMMENT '父评论ID',
    like_count INT NOT NULL DEFAULT 0 COMMENT '点赞数',
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否删除',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    FOREIGN KEY (article_id) REFERENCES t_article(id),
    FOREIGN KEY (post_id) REFERENCES t_post(id),
    FOREIGN KEY (user_id) REFERENCES t_user(id),
    FOREIGN KEY (parent_id) REFERENCES t_comment(id)
) COMMENT='评论表';

-- 用户收藏表
CREATE TABLE IF NOT EXISTS t_user_favorite (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '收藏ID',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    article_id BIGINT DEFAULT NULL COMMENT '收藏的文章ID',
    post_id BIGINT DEFAULT NULL COMMENT '收藏的帖子ID',
    psych_info_id BIGINT DEFAULT NULL COMMENT '收藏的心理资讯ID',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    FOREIGN KEY (user_id) REFERENCES t_user(id),
    FOREIGN KEY (article_id) REFERENCES t_article(id),
    FOREIGN KEY (post_id) REFERENCES t_post(id),
    FOREIGN KEY (psych_info_id) REFERENCES t_psych_info(id)
) COMMENT='用户收藏表';

-- 留言表
CREATE TABLE IF NOT EXISTS t_message (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '留言ID',
    user_id BIGINT NOT NULL COMMENT '留言用户ID',
    content TEXT NOT NULL COMMENT '留言内容',
    is_public BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否公开',
    is_replied BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否已回复',
    reply TEXT DEFAULT NULL COMMENT '回复内容',
    reply_user_id BIGINT DEFAULT NULL COMMENT '回复用户ID',
    reply_time DATETIME DEFAULT NULL COMMENT '回复时间',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    FOREIGN KEY (user_id) REFERENCES t_user(id),
    FOREIGN KEY (reply_user_id) REFERENCES t_user(id)
) COMMENT='留言表';

-- 心理预约表
CREATE TABLE IF NOT EXISTS t_appointment (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '预约ID',
    student_id BIGINT NOT NULL COMMENT '预约学生ID',
    teacher_id BIGINT NOT NULL COMMENT '心理老师ID',
    appointment_time DATETIME NOT NULL COMMENT '预约时间',
    duration INT NOT NULL DEFAULT 60 COMMENT '时长（分钟）',
    description VARCHAR(500) COMMENT '预约描述',
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' COMMENT '状态',
    cancel_reason VARCHAR(500) COMMENT '取消原因',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    FOREIGN KEY (student_id) REFERENCES t_user(id),
    FOREIGN KEY (teacher_id) REFERENCES t_user(id)
) COMMENT='心理预约表';

-- 在线咨询表
CREATE TABLE IF NOT EXISTS t_consultation (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '咨询ID',
    student_id BIGINT NOT NULL COMMENT '学生ID',
    teacher_id BIGINT NOT NULL COMMENT '心理老师ID',
    title VARCHAR(100) COMMENT '咨询标题',
    status VARCHAR(20) NOT NULL DEFAULT 'ONGOING' COMMENT '状态',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间',
    close_time DATETIME DEFAULT NULL COMMENT '关闭时间',
    FOREIGN KEY (student_id) REFERENCES t_user(id),
    FOREIGN KEY (teacher_id) REFERENCES t_user(id)
) COMMENT='在线咨询表';

-- 咨询消息表
CREATE TABLE IF NOT EXISTS t_consultation_message (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '消息ID',
    consultation_id BIGINT NOT NULL COMMENT '咨询ID',
    sender_id BIGINT NOT NULL COMMENT '发送者ID',
    content TEXT NOT NULL COMMENT '消息内容',
    attachment VARCHAR(200) COMMENT '附件',
    is_read BOOLEAN NOT NULL DEFAULT FALSE COMMENT '是否已读',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发送时间',
    FOREIGN KEY (consultation_id) REFERENCES t_consultation(id),
    FOREIGN KEY (sender_id) REFERENCES t_user(id)
) COMMENT='咨询消息表';

-- 轮播图表
CREATE TABLE IF NOT EXISTS t_banner (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '轮播图ID',
    title VARCHAR(100) NOT NULL COMMENT '标题',
    image_url VARCHAR(200) NOT NULL COMMENT '图片地址',
    link_url VARCHAR(200) COMMENT '链接地址',
    description VARCHAR(200) COMMENT '描述',
    sort INT NOT NULL DEFAULT 0 COMMENT '排序',
    enabled BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否启用',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间'
) COMMENT='轮播图表';

-- 系统表
CREATE TABLE t_system_config (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '配置ID',
    config_key VARCHAR(50) NOT NULL UNIQUE COMMENT '配置键',
    config_value VARCHAR(500) NOT NULL COMMENT '配置值',
    description VARCHAR(200) COMMENT '描述',
    enabled BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否启用',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间'
) COMMENT='系统配置表';

-- 关于我们表
CREATE TABLE IF NOT EXISTS t_about (
    id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '记录ID',
    title VARCHAR(100) NOT NULL COMMENT '标题',
    content TEXT NOT NULL COMMENT '内容',
    logo VARCHAR(200) COMMENT 'Logo 图片',
    email VARCHAR(100) COMMENT '邮箱',
    phone VARCHAR(100) COMMENT '电话',
    address VARCHAR(200) COMMENT '地址',
    copyright VARCHAR(200) COMMENT '版权信息',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME DEFAULT NULL COMMENT '更新时间'
) COMMENT='关于我们表';