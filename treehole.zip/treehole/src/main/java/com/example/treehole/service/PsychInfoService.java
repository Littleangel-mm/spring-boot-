package com.example.treehole.service;

import com.example.treehole.model.entity.PsychInfo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface PsychInfoService {
    
    PsychInfo save(PsychInfo psychInfo);
    
    Optional<PsychInfo> findById(Long id);
    
    Optional<PsychInfo> findByUserId(Long userId);
    
    List<PsychInfo> findAllApproved();
    
    Page<PsychInfo> findAll(Pageable pageable);
    
    void deleteById(Long id);
    
    boolean approve(Long id, boolean approved);
}