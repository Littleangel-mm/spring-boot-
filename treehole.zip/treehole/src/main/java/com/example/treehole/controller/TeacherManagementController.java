package com.example.treehole.controller;

import com.example.treehole.model.entity.PsychInfo;
import com.example.treehole.model.entity.User;
import com.example.treehole.service.PsychInfoService;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin/teachers")
@RequiredArgsConstructor
public class TeacherManagementController {

    private final UserService userService;
    private final PsychInfoService psychInfoService;

    /**
     * 获取所有心理老师列表（分页）
     */
    @GetMapping
    public ResponseEntity<?> getAllTeachers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<User> teachers = userService.findByRole("teacher", pageable);
            
            // 移除密码信息
            teachers.getContent().forEach(teacher -> teacher.setPassword(null));
            
            return ResponseEntity.ok(teachers);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取心理老师列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取心理老师详细信息（包括基本信息和心理咨询师信息）
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getTeacherDetail(@PathVariable Long id) {
        try {
            Optional<User> userOpt = userService.findById(id);
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("用户不存在");
            }
            
            User teacher = userOpt.get();
            
            // 检查用户是否为心理老师
            if (!"teacher".equals(teacher.getRole())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("该用户不是心理老师");
            }
            
            // 获取心理咨询师信息
            Optional<PsychInfo> psychInfoOpt = psychInfoService.findByUserId(id);
            
            Map<String, Object> result = new HashMap<>();
            teacher.setPassword(null); // 不返回密码
            result.put("userInfo", teacher);
            result.put("psychInfo", psychInfoOpt.orElse(null));
            
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取心理老师详情失败: " + e.getMessage());
        }
    }

    /**
     * 获取待审核的心理老师申请列表
     */
    @GetMapping("/pending-approval")
    public ResponseEntity<?> getPendingApprovalTeachers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createTime"));
            Page<PsychInfo> allPsychInfos = psychInfoService.findAll(pageable);
            
            // 过滤出未审核的申请
            List<PsychInfo> pendingList = allPsychInfos.getContent().stream()
                    .filter(psychInfo -> psychInfo.getApproved() == null || !psychInfo.getApproved())
                    .collect(Collectors.toList());
            
            // 创建新的Page对象
            Page<PsychInfo> pendingPsychInfos = new PageImpl<>(
                    pendingList, 
                    pageable, 
                    pendingList.size() // 这里简化处理，实际上应该查询总数
            );
            
            return ResponseEntity.ok(pendingPsychInfos);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取待审核心理老师列表失败: " + e.getMessage());
        }
    }

    /**
     * 审核脑老师申请
     */
    @PutMapping("/approve/{id}")
    public ResponseEntity<?> approveTeacher(
            @PathVariable Long id,
            @RequestParam boolean approved,
            @RequestParam(required = false) String reason) {
        try {
            Optional<PsychInfo> psychInfoOpt = psychInfoService.findById(id);
            if (psychInfoOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询师信息不存在");
            }
            
            PsychInfo psychInfo = psychInfoOpt.get();
            Long userId = psychInfo.getUserId();
            
            // 更新咨询师信息的审核状态
            boolean psychInfoUpdated = psychInfoService.approve(id, approved);
            
            if (!psychInfoUpdated) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("更新审核状态失败");
            }
            
            // 如果审核通过，将用户角色更新为teacher
            if (approved) {
                Optional<User> userOpt = userService.findById(userId);
                if (userOpt.isPresent()) {
                    User user = userOpt.get();
                    user.setRole("teacher");
                    userService.save(user);
                }
            }
            
            Map<String, Object> result = new HashMap<>();
            result.put("message", approved ? "审核通过" : "审核拒绝");
            result.put("reason", reason);
            
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("审核脑老师申请失败: " + e.getMessage());
        }
    }

    /**
     * 启用/禁用脑老师账户
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateTeacherStatus(
            @PathVariable Long id,
            @RequestParam boolean enabled,
            @RequestParam(required = false) String reason) {
        try {
            Optional<User> userOpt = userService.findById(id);
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("用户不存在");
            }
            
            User user = userOpt.get();
            
            // 检查用户是否为脑老师
            if (!"teacher".equals(user.getRole())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("该用户不是脑老师");
            }
            
            // 更新用户状态
            boolean updated = userService.enableUser(id, enabled);
            
            if (updated) {
                Map<String, Object> result = new HashMap<>();
                result.put("message", enabled ? "脑老师账户已启用" : "脑老师账户已禁用");
                result.put("reason", reason);
                
                return ResponseEntity.ok(result);
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("更新脑老师状态失败");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新脑老师状态失败: " + e.getMessage());
        }
    }

    /**
     * 获取脑老师统计信息
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getTeacherStatistics() {
        try {
            // 获取所有脑老师
            Pageable pageable = PageRequest.of(0, 1);
            Page<User> teachers = userService.findByRole("teacher", pageable);
            long totalTeachers = teachers.getTotalElements();
            
            // 获取所有待审核的申请
            Page<PsychInfo> allPsychInfos = psychInfoService.findAll(pageable);
            List<PsychInfo> pendingApprovals = allPsychInfos.getContent().stream()
                    .filter(psychInfo -> psychInfo.getApproved() == null || !psychInfo.getApproved())
                    .collect(Collectors.toList());
            long pendingCount = pendingApprovals.size();
            
            // 获取已审核通过的申请
            List<PsychInfo> approvedPsychInfos = psychInfoService.findAllApproved();
            long approvedCount = approvedPsychInfos.size();
            
            Map<String, Object> statistics = new HashMap<>();
            statistics.put("totalTeachers", totalTeachers);
            statistics.put("pendingApprovalCount", pendingCount);
            statistics.put("approvedCount", approvedCount);
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取脑老师统计信息失败: " + e.getMessage());
        }
    }
}