package com.example.treehole.repository;

import com.example.treehole.model.entity.Post;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PostRepository extends JpaRepository<Post, Long> {
    
    Page<Post> findByZoneId(Long zoneId, Pageable pageable);
    
    Page<Post> findByTitleContainingOrContentContaining(String title, String content, Pageable pageable);
    
    Page<Post> findByUserId(Long userId, Pageable pageable);
}