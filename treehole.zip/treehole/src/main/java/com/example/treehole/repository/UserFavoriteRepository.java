package com.example.treehole.repository;

import com.example.treehole.model.entity.UserFavorite;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserFavoriteRepository extends JpaRepository<UserFavorite, Long> {
    
    Page<UserFavorite> findByUserId(Long userId, Pageable pageable);
    
    Optional<UserFavorite> findByUserIdAndArticleId(Long userId, Long articleId);
    
    Optional<UserFavorite> findByUserIdAndPostId(Long userId, Long postId);
    
    Optional<UserFavorite> findByUserIdAndPsychInfoId(Long userId, Long psychInfoId);
    
    boolean existsByUserIdAndArticleId(Long userId, Long articleId);
    
    boolean existsByUserIdAndPostId(Long userId, Long postId);
    
    boolean existsByUserIdAndPsychInfoId(Long userId, Long psychInfoId);
    
    void deleteByUserIdAndArticleId(Long userId, Long articleId);
    
    void deleteByUserIdAndPostId(Long userId, Long postId);
    
    void deleteByUserIdAndPsychInfoId(Long userId, Long psychInfoId);
}