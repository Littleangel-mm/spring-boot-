package com.example.treehole.controller;

import com.example.treehole.model.entity.Article;
import com.example.treehole.model.entity.Category;
import com.example.treehole.model.entity.User;
import com.example.treehole.service.ArticleService;
import com.example.treehole.service.CategoryService;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Optional;

@RestController
@RequestMapping("/articles")
@RequiredArgsConstructor
public class ArticleController {

    private final ArticleService articleService;
    private final CategoryService categoryService;
    private final UserService userService;

    /**
     * 创建新文章
     */
    @PostMapping
    public ResponseEntity<?> createArticle(@RequestBody Article article, 
                                          @RequestParam Long authorId, 
                                          @RequestParam Long categoryId) {
        try {
            // 检查作者是否存在
            Optional<User> authorOpt = userService.findById(authorId);
            if (authorOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("作者不存在");
            }
            
            // 检查分类是否存在
            Optional<Category> categoryOpt = categoryService.findById(categoryId);
            if (categoryOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分类不存在");
            }
            
            // 设置作者和分类
            article.setAuthor(authorOpt.get());
            article.setCategory(categoryOpt.get());
            
            // 设置发布时间
            LocalDateTime now = LocalDateTime.now();
            article.setPublishTime(now);
            
            // 保存文章
            Article savedArticle = articleService.save(article);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedArticle);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("创建文章失败: " + e.getMessage());
        }
    }

    /**
     * 获取文章详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getArticleById(@PathVariable Long id) {
        try {
            Optional<Article> articleOpt = articleService.findById(id);
            if (articleOpt.isPresent()) {
                // 增加浏览量
                Article article = articleService.incrementViewCount(id);
                return ResponseEntity.ok(article);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("文章不存在");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取文章失败: " + e.getMessage());
        }
    }

    /**
     * 更新文章
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateArticle(@PathVariable Long id, @RequestBody Article article) {
        try {
            Optional<Article> articleOpt = articleService.findById(id);
            if (articleOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("文章不存在");
            }
            
            Article existingArticle = articleOpt.get();
            
            // 更新文章信息
            existingArticle.setTitle(article.getTitle());
            existingArticle.setContent(article.getContent());
            existingArticle.setCoverImage(article.getCoverImage());
            existingArticle.setIsTop(article.getIsTop());
            existingArticle.setIsRecommend(article.getIsRecommend());
            existingArticle.setStatus(article.getStatus());
            
            // 如果提供了分类ID，则更新分类
            if (article.getCategory() != null && article.getCategory().getId() != null) {
                Optional<Category> categoryOpt = categoryService.findById(article.getCategory().getId());
                if (categoryOpt.isPresent()) {
                    existingArticle.setCategory(categoryOpt.get());
                } else {
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分类不存在");
                }
            }
            
            // 保存更新后的文章
            Article updatedArticle = articleService.save(existingArticle);
            return ResponseEntity.ok(updatedArticle);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("更新文章失败: " + e.getMessage());
        }
    }

    /**
     * 删除文章
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteArticle(@PathVariable Long id) {
        try {
            Optional<Article> articleOpt = articleService.findById(id);
            if (articleOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("文章不存在");
            }
            
            articleService.deleteById(id);
            return ResponseEntity.ok("文章已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("删除文章失败: " + e.getMessage());
        }
    }

    /**
     * 获取文章列表（分页）
     */
    @GetMapping
    public ResponseEntity<?> getArticles(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createTime"));
            Page<Article> articles = articleService.findAll(pageable);
            return ResponseEntity.ok(articles);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取文章列表失败: " + e.getMessage());
        }
    }

    /**
     * 按分类获取文章列表（分页）
     */
    @GetMapping("/category/{categoryId}")
    public ResponseEntity<?> getArticlesByCategory(
            @PathVariable Long categoryId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            // 检查分类是否存在
            Optional<Category> categoryOpt = categoryService.findById(categoryId);
            if (categoryOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分类不存在");
            }
            
            Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createTime"));
            Page<Article> articles = articleService.findByCategoryId(categoryId, pageable);
            return ResponseEntity.ok(articles);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取分类文章列表失败: " + e.getMessage());
        }
    }

    /**
     * 按作者获取文章列表（分页）
     */
    @GetMapping("/author/{authorId}")
    public ResponseEntity<?> getArticlesByAuthor(
            @PathVariable Long authorId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            // 检查作者是否存在
            Optional<User> authorOpt = userService.findById(authorId);
            if (authorOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("作者不存在");
            }
            
            Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createTime"));
            Page<Article> articles = articleService.findByAuthorId(authorId, pageable);
            return ResponseEntity.ok(articles);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取作者文章列表失败: " + e.getMessage());
        }
    }

    /**
     * 搜索文章（分页）
     */
    @GetMapping("/search")
    public ResponseEntity<?> searchArticles(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createTime"));
            Page<Article> articles = articleService.search(keyword, pageable);
            return ResponseEntity.ok(articles);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("搜索文章失败: " + e.getMessage());
        }
    }
}