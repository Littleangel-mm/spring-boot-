package com.example.treehole.repository;

import com.example.treehole.model.entity.Message;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MessageRepository extends JpaRepository<Message, Long> {
    
    // 如果需要按用户ID查询消息，可以使用以下方法
    Page<Message> findByUserIdOrderByCreateTimeDesc(Long userId, Pageable pageable);
    
    // 如果需要按回复用户ID查询消息，可以使用以下方法
    Page<Message> findByReplyUserIdOrderByCreateTimeDesc(Long replyUserId, Pageable pageable);
    
    // 如果需要统计未回复的消息数量，可以使用以下方法
    int countByIsRepliedFalse();
    
    // 如果需要统计特定用户未回复的消息数量，可以使用以下方法
    int countByUserIdAndIsRepliedFalse(Long userId);
}