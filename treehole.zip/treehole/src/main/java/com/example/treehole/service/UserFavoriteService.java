package com.example.treehole.service;

import com.example.treehole.model.entity.UserFavorite;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

public interface UserFavoriteService {
    
    /**
     * 添加收藏
     */
    UserFavorite addFavorite(UserFavorite userFavorite);
    
    /**
     * 根据ID查找收藏
     */
    Optional<UserFavorite> findById(Long id);
    
    /**
     * 根据用户ID分页查询收藏列表
     */
    Page<UserFavorite> findByUserId(Long userId, Pageable pageable);
    
    /**
     * 检查用户是否已收藏文章
     */
    boolean existsByUserIdAndArticleId(Long userId, Long articleId);
    
    /**
     * 检查用户是否已收藏帖子
     */
    boolean existsByUserIdAndPostId(Long userId, Long postId);
    
    /**
     * 检查用户是否已收藏心理资讯
     */
    boolean existsByUserIdAndPsychInfoId(Long userId, Long psychInfoId);
    
    /**
     * 根据用户ID和文章ID查找收藏
     */
    Optional<UserFavorite> findByUserIdAndArticleId(Long userId, Long articleId);
    
    /**
     * 根据用户ID和帖子ID查找收藏
     */
    Optional<UserFavorite> findByUserIdAndPostId(Long userId, Long postId);
    
    /**
     * 根据用户ID和心理资讯ID查找收藏
     */
    Optional<UserFavorite> findByUserIdAndPsychInfoId(Long userId, Long psychInfoId);
    
    /**
     * 取消文章收藏
     */
    void removeArticleFavorite(Long userId, Long articleId);
    
    /**
     * 取消帖子收藏
     */
    void removePostFavorite(Long userId, Long postId);
    
    /**
     * 取消心理资讯收藏
     */
    void removePsychInfoFavorite(Long userId, Long psychInfoId);
    
    /**
     * 删除收藏
     */
    void deleteById(Long id);
}