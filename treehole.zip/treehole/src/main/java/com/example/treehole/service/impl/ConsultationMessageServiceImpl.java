package com.example.treehole.service.impl;

import com.example.treehole.model.entity.ConsultationMessage;
import com.example.treehole.repository.ConsultationMessageRepository;
import com.example.treehole.service.ConsultationMessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ConsultationMessageServiceImpl implements ConsultationMessageService {
    
    private final ConsultationMessageRepository consultationMessageRepository;
    
    @Override
    @Transactional
    public ConsultationMessage save(ConsultationMessage message) {
        if (message.getCreateTime() == null) {
            message.setCreateTime(LocalDateTime.now());
        }
        if (message.getIsRead() == null) {
            message.setIsRead(false);
        }
        return consultationMessageRepository.save(message);
    }
    
    @Override
    public Optional<ConsultationMessage> findById(Long id) {
        return consultationMessageRepository.findById(id);
    }
    
    @Override
    public List<ConsultationMessage> findByConsultationId(Long consultationId) {
        return consultationMessageRepository.findByConsultationIdOrderByCreateTimeAsc(consultationId);
    }
    
    @Override
    @Transactional
    public ConsultationMessage markAsRead(Long id) {
        Optional<ConsultationMessage> messageOpt = consultationMessageRepository.findById(id);
        if (messageOpt.isPresent()) {
            ConsultationMessage message = messageOpt.get();
            message.setIsRead(true);
            return consultationMessageRepository.save(message);
        }
        return null;
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        consultationMessageRepository.deleteById(id);
    }
}