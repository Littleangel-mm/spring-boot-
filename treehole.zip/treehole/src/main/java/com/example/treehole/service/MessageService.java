package com.example.treehole.service;

import com.example.treehole.model.entity.Message;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

public interface MessageService {
    
    Message save(Message message);
    
    Optional<Message> findById(Long id);
    
    Page<Message> findByUserId(Long userId, Pageable pageable);
    
    Page<Message> findByReplyUserId(Long replyUserId, Pageable pageable);
    
    int countUnrepliedMessages();
    
    int countUnrepliedMessagesByUserId(Long userId);
    
    void deleteById(Long id);
    
    Message reply(Long messageId, String replyContent, Long replyUserId);
}