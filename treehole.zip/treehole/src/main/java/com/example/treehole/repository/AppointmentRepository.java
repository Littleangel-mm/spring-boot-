package com.example.treehole.repository;

import com.example.treehole.model.entity.Appointment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    
    Page<Appointment> findByStudentId(Long studentId, Pageable pageable);
    
    Page<Appointment> findByTeacherId(Long teacherId, Pageable pageable);
    
    Page<Appointment> findByStatus(String status, Pageable pageable);
    
    List<Appointment> findByTeacherIdAndAppointmentTimeBetween(
            Long teacherId, LocalDateTime start, LocalDateTime end);
}