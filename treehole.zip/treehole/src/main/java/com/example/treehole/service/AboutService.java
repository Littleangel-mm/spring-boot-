package com.example.treehole.service;

import com.example.treehole.model.entity.About;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface AboutService {
    
    /**
     * 保存About（新增或更新）
     */
    About save(About about);
    
    /**
     * 根据ID查找About
     */
    Optional<About> findById(Long id);
    
    /**
     * 分页查询所有About
     */
    Page<About> findAll(Pageable pageable);
    
    /**
     * 查询所有About
     */
    List<About> findAll();
    
    /**
     * 根据ID删除About
     */
    void deleteById(Long id);
}