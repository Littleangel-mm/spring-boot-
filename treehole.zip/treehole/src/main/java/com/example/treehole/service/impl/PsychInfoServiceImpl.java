package com.example.treehole.service.impl;

import com.example.treehole.model.entity.PsychInfo;
import com.example.treehole.repository.PsychInfoRepository;
import com.example.treehole.service.PsychInfoService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PsychInfoServiceImpl implements PsychInfoService {
    
    private final PsychInfoRepository psychInfoRepository;
    
    @Override
    @Transactional
    public PsychInfo save(PsychInfo psychInfo) {
        if (psychInfo.getId() == null) {
            psychInfo.setCreateTime(LocalDateTime.now());
            // 新增心理咨询师信息默认未审核
            if (psychInfo.getApproved() == null) {
                psychInfo.setApproved(false);
            }
        }
        psychInfo.setUpdateTime(LocalDateTime.now());
        return psychInfoRepository.save(psychInfo);
    }
    
    @Override
    public Optional<PsychInfo> findById(Long id) {
        return psychInfoRepository.findById(id);
    }
    
    @Override
    public Optional<PsychInfo> findByUserId(Long userId) {
        return psychInfoRepository.findByUserId(userId);
    }
    
    @Override
    public List<PsychInfo> findAllApproved() {
        return psychInfoRepository.findByApprovedTrue();
    }
    
    @Override
    public Page<PsychInfo> findAll(Pageable pageable) {
        return psychInfoRepository.findAll(pageable);
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        psychInfoRepository.deleteById(id);
    }
    
    @Override
    @Transactional
    public boolean approve(Long id, boolean approved) {
        Optional<PsychInfo> psychInfoOpt = psychInfoRepository.findById(id);
        if (psychInfoOpt.isPresent()) {
            PsychInfo psychInfo = psychInfoOpt.get();
            psychInfo.setApproved(approved);
            psychInfo.setUpdateTime(LocalDateTime.now());
            psychInfoRepository.save(psychInfo);
            return true;
        }
        return false;
    }
}