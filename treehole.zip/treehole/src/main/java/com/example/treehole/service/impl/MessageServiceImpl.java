package com.example.treehole.service.impl;

import com.example.treehole.model.entity.Message;
import com.example.treehole.model.entity.User;
import com.example.treehole.repository.MessageRepository;
import com.example.treehole.repository.UserRepository;
import com.example.treehole.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MessageServiceImpl implements MessageService {
    
    private final MessageRepository messageRepository;
    private final UserRepository userRepository;
    
    @Override
    @Transactional
    public Message save(Message message) {
        if (message.getCreateTime() == null) {
            message.setCreateTime(LocalDateTime.now());
        }
        return messageRepository.save(message);
    }
    
    @Override
    public Optional<Message> findById(Long id) {
        return messageRepository.findById(id);
    }
    
    @Override
    public Page<Message> findByUserId(Long userId, Pageable pageable) {
        return messageRepository.findByUserIdOrderByCreateTimeDesc(userId, pageable);
    }
    
    @Override
    public Page<Message> findByReplyUserId(Long replyUserId, Pageable pageable) {
        return messageRepository.findByReplyUserIdOrderByCreateTimeDesc(replyUserId, pageable);
    }
    
    @Override
    public int countUnrepliedMessages() {
        return messageRepository.countByIsRepliedFalse();
    }
    
    @Override
    public int countUnrepliedMessagesByUserId(Long userId) {
        return messageRepository.countByUserIdAndIsRepliedFalse(userId);
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        messageRepository.deleteById(id);
    }
    
    @Override
    @Transactional
    public Message reply(Long messageId, String replyContent, Long replyUserId) {
        Optional<Message> messageOpt = messageRepository.findById(messageId);
        Optional<User> replyUserOpt = userRepository.findById(replyUserId);
        
        if (messageOpt.isPresent() && replyUserOpt.isPresent()) {
            Message message = messageOpt.get();
            User replyUser = replyUserOpt.get();
            
            message.setReply(replyContent);
            message.setReplyUser(replyUser);
            message.setReplyTime(LocalDateTime.now());
            message.setIsReplied(true);
            
            return messageRepository.save(message);
        }
        
        throw new RuntimeException("消息或回复用户不存在");
    }
}