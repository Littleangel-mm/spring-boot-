package com.example.treehole.controller;

import com.example.treehole.model.entity.SystemConfig;
import com.example.treehole.service.SystemConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/admin/system")
@RequiredArgsConstructor
public class SystemManagementController {

    private final SystemConfigService systemConfigService;

    /**
     * 获取所有系统配置（分页）
     */
    @GetMapping("/configs")
    public ResponseEntity<?> getAllConfigs(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "configKey") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<SystemConfig> configs = systemConfigService.findAll(pageable);
            
            return ResponseEntity.ok(configs);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取系统配置列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取系统配置详情
     */
    @GetMapping("/configs/{id}")
    public ResponseEntity<?> getConfigDetail(@PathVariable Long id) {
        try {
            Optional<SystemConfig> configOpt = systemConfigService.findById(id);
            if (configOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("系统配置不存在");
            }
            
            return ResponseEntity.ok(configOpt.get());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取系统配置详情失败: " + e.getMessage());
        }
    }

    /**
     * 根据配置键获取系统配置
     */
    @GetMapping("/configs/key/{configKey}")
    public ResponseEntity<?> getConfigByKey(@PathVariable String configKey) {
        try {
            Optional<SystemConfig> configOpt = systemConfigService.findByConfigKey(configKey);
            if (configOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("系统配置不存在");
            }
            
            return ResponseEntity.ok(configOpt.get());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取系统配置详情失败: " + e.getMessage());
        }
    }

    /**
     * 创建系统配置
     */
    @PostMapping("/configs")
    public ResponseEntity<?> createConfig(@RequestBody SystemConfig config) {
        try {
            // 检查配置键是否已存在
            Optional<SystemConfig> existingConfig = systemConfigService.findByConfigKey(config.getConfigKey());
            if (existingConfig.isPresent()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("配置键已存在");
            }
            
            // 设置创建时间和更新时间
            LocalDateTime now = LocalDateTime.now();
            config.setCreateTime(now);
            config.setUpdateTime(now);
            
            // 如果没有设置启用状态，默认为true
            if (config.getEnabled() == null) {
                config.setEnabled(true);
            }
            
            SystemConfig savedConfig = systemConfigService.save(config);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedConfig);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("创建系统配置失败: " + e.getMessage());
        }
    }

    /**
     * 更新系统配置
     */
    @PutMapping("/configs/{id}")
    public ResponseEntity<?> updateConfig(@PathVariable Long id, @RequestBody SystemConfig config) {
        try {
            Optional<SystemConfig> existingConfigOpt = systemConfigService.findById(id);
            if (existingConfigOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("系统配置不存在");
            }
            
            SystemConfig existingConfig = existingConfigOpt.get();
            
            // 如果配置键发生变化，检查新的配置键是否已存在
            if (!existingConfig.getConfigKey().equals(config.getConfigKey())) {
                Optional<SystemConfig> duplicateConfig = systemConfigService.findByConfigKey(config.getConfigKey());
                if (duplicateConfig.isPresent()) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("配置键已存在");
                }
            }
            
            // 更新字段
            existingConfig.setConfigKey(config.getConfigKey());
            existingConfig.setConfigValue(config.getConfigValue());
            existingConfig.setDescription(config.getDescription());
            existingConfig.setEnabled(config.getEnabled());
            existingConfig.setUpdateTime(LocalDateTime.now());
            
            SystemConfig updatedConfig = systemConfigService.save(existingConfig);
            return ResponseEntity.ok(updatedConfig);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新系统配置失败: " + e.getMessage());
        }
    }

    /**
     * 删除系统配置
     */
    @DeleteMapping("/configs/{id}")
    public ResponseEntity<?> deleteConfig(@PathVariable Long id) {
        try {
            Optional<SystemConfig> configOpt = systemConfigService.findById(id);
            if (configOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("系统配置不存在");
            }
            
            systemConfigService.deleteById(id);
            return ResponseEntity.ok("系统配置删除成功");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("删除系统配置失败: " + e.getMessage());
        }
    }

    /**
     * 更新系统配置状态（启用/禁用）
     */
    @PutMapping("/configs/{id}/status")
    public ResponseEntity<?> updateConfigStatus(
            @PathVariable Long id, 
            @RequestParam Boolean enabled) {
        try {
            SystemConfig config = systemConfigService.updateStatus(id, enabled);
            if (config == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("系统配置不存在");
            }
            
            return ResponseEntity.ok(config);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新系统配置状态失败: " + e.getMessage());
        }
    }

    /**
     * 批量更新系统配置
     */
    @PutMapping("/configs/batch")
    public ResponseEntity<?> batchUpdateConfigs(@RequestBody Map<String, String> configMap) {
        try {
            List<SystemConfig> updatedConfigs = systemConfigService.batchUpdate(configMap);
            return ResponseEntity.ok(updatedConfigs);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("批量更新系统配置失败: " + e.getMessage());
        }
    }

    /**
     * 获取所有启用的系统配置（前台使用）
     */
    @GetMapping("/configs/enabled")
    public ResponseEntity<?> getAllEnabledConfigs() {
        try {
            Map<String, String> configMap = systemConfigService.getAllConfigMap();
            return ResponseEntity.ok(configMap);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取启用的系统配置失败: " + e.getMessage());
        }
    }

    /**
     * 获取系统配置统计信息
     */
    @GetMapping("/configs/statistics")
    public ResponseEntity<?> getConfigStatistics() {
        try {
            Page<SystemConfig> allConfigs = systemConfigService.findAll(Pageable.unpaged());
            List<SystemConfig> enabledConfigs = systemConfigService.findAllEnabled();
            
            Map<String, Object> statistics = new HashMap<>();
            statistics.put("totalConfigs", allConfigs.getTotalElements());
            statistics.put("enabledConfigs", enabledConfigs.size());
            statistics.put("disabledConfigs", allConfigs.getTotalElements() - enabledConfigs.size());
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取系统配置统计信息失败: " + e.getMessage());
        }
    }

    /**
     * 获取系统信息
     */
    @GetMapping("/info")
    public ResponseEntity<?> getSystemInfo() {
        try {
            Map<String, Object> systemInfo = new HashMap<>();
            
            // 获取Java版本
            systemInfo.put("javaVersion", System.getProperty("java.version"));
            // 获取操作系统信息
            systemInfo.put("osName", System.getProperty("os.name"));
            systemInfo.put("osVersion", System.getProperty("os.version"));
            // 获取服务器时间
            systemInfo.put("serverTime", LocalDateTime.now());
            // 获取JVM内存信息
            Runtime runtime = Runtime.getRuntime();
            long totalMemory = runtime.totalMemory() / (1024 * 1024);
            long freeMemory = runtime.freeMemory() / (1024 * 1024);
            long maxMemory = runtime.maxMemory() / (1024 * 1024);
            systemInfo.put("totalMemory", totalMemory + "MB");
            systemInfo.put("freeMemory", freeMemory + "MB");
            systemInfo.put("usedMemory", (totalMemory - freeMemory) + "MB");
            systemInfo.put("maxMemory", maxMemory + "MB");
            
            return ResponseEntity.ok(systemInfo);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取系统信息失败: " + e.getMessage());
        }
    }
}