package com.example.treehole.service.impl;

import com.example.treehole.model.entity.SystemConfig;
import com.example.treehole.repository.SystemConfigRepository;
import com.example.treehole.service.SystemConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SystemConfigServiceImpl implements SystemConfigService {
    
    private final SystemConfigRepository systemConfigRepository;
    
    @Override
    @Transactional
    public SystemConfig save(SystemConfig systemConfig) {
        LocalDateTime now = LocalDateTime.now();
        if (systemConfig.getId() == null) {
            // 新增配置
            systemConfig.setCreateTime(now);
        }
        systemConfig.setUpdateTime(now);
        return systemConfigRepository.save(systemConfig);
    }
    
    @Override
    public Optional<SystemConfig> findById(Long id) {
        return systemConfigRepository.findById(id);
    }
    
    @Override
    public Optional<SystemConfig> findByConfigKey(String configKey) {
        return systemConfigRepository.findByConfigKey(configKey);
    }
    
    @Override
    public Page<SystemConfig> findAll(Pageable pageable) {
        return systemConfigRepository.findAll(pageable);
    }
    
    @Override
    public List<SystemConfig> findAllEnabled() {
        return systemConfigRepository.findByEnabledTrue();
    }
    
    @Override
    public Map<String, String> getAllConfigMap() {
        List<SystemConfig> configs = systemConfigRepository.findByEnabledTrue();
        return configs.stream()
                .collect(Collectors.toMap(SystemConfig::getConfigKey, SystemConfig::getConfigValue));
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        systemConfigRepository.deleteById(id);
    }
    
    @Override
    @Transactional
    public SystemConfig updateStatus(Long id, Boolean enabled) {
        Optional<SystemConfig> configOpt = systemConfigRepository.findById(id);
        if (configOpt.isPresent()) {
            SystemConfig config = configOpt.get();
            config.setEnabled(enabled);
            config.setUpdateTime(LocalDateTime.now());
            return systemConfigRepository.save(config);
        }
        return null;
    }
    
    @Override
    @Transactional
    public List<SystemConfig> batchUpdate(Map<String, String> configMap) {
        List<SystemConfig> updatedConfigs = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        
        for (Map.Entry<String, String> entry : configMap.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            
            Optional<SystemConfig> configOpt = systemConfigRepository.findByConfigKey(key);
            if (configOpt.isPresent()) {
                // 更新已存在的配置
                SystemConfig config = configOpt.get();
                config.setConfigValue(value);
                config.setUpdateTime(now);
                updatedConfigs.add(systemConfigRepository.save(config));
            } else {
                // 创建新配置
                SystemConfig newConfig = new SystemConfig();
                newConfig.setConfigKey(key);
                newConfig.setConfigValue(value);
                newConfig.setEnabled(true);
                newConfig.setCreateTime(now);
                newConfig.setUpdateTime(now);
                updatedConfigs.add(systemConfigRepository.save(newConfig));
            }
        }
        
        return updatedConfigs;
    }
}