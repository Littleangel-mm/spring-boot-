package com.example.treehole.service.impl;

import com.example.treehole.model.entity.Appointment;
import com.example.treehole.repository.AppointmentRepository;
import com.example.treehole.service.AppointmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AppointmentServiceImpl implements AppointmentService {
    
    private final AppointmentRepository appointmentRepository;
    
    @Override
    @Transactional
    public Appointment save(Appointment appointment) {
        if (appointment.getId() == null) {
            // 新预约
            LocalDateTime now = LocalDateTime.now();
            appointment.setCreateTime(now);
            appointment.setUpdateTime(now);
            if (appointment.getStatus() == null) {
                appointment.setStatus("PENDING");
            }
        } else {
            // 更新预约
            appointment.setUpdateTime(LocalDateTime.now());
        }
        return appointmentRepository.save(appointment);
    }
    
    @Override
    public Optional<Appointment> findById(Long id) {
        return appointmentRepository.findById(id);
    }
    
    @Override
    public Page<Appointment> findAll(Pageable pageable) {
        return appointmentRepository.findAll(pageable);
    }
    
    @Override
    public Page<Appointment> findByStudentId(Long studentId, Pageable pageable) {
        return appointmentRepository.findByStudentId(studentId, pageable);
    }
    
    @Override
    public Page<Appointment> findByTeacherId(Long teacherId, Pageable pageable) {
        return appointmentRepository.findByTeacherId(teacherId, pageable);
    }
    
    @Override
    public Page<Appointment> findByStatus(String status, Pageable pageable) {
        // 需要在 AppointmentRepository 中添加相应的方法
        // 这里使用内存过滤作为临时解决方案
        Page<Appointment> allAppointments = appointmentRepository.findAll(pageable);
        List<Appointment> filteredAppointments = allAppointments.getContent().stream()
                .filter(appointment -> status.equals(appointment.getStatus()))
                .collect(Collectors.toList());
        
        return new PageImpl<>(filteredAppointments, pageable, filteredAppointments.size());
    }
    
    @Override
    public List<Appointment> findByTeacherIdAndTimeBetween(Long teacherId, LocalDateTime start, LocalDateTime end) {
        return appointmentRepository.findByTeacherIdAndAppointmentTimeBetween(teacherId, start, end);
    }
    
    @Override
    @Transactional
    public Appointment updateStatus(Long id, String status, String cancelReason) {
        Optional<Appointment> appointmentOpt = appointmentRepository.findById(id);
        if (appointmentOpt.isPresent()) {
            Appointment appointment = appointmentOpt.get();
            appointment.setStatus(status);
            appointment.setUpdateTime(LocalDateTime.now());
            
            if ("CANCELLED".equals(status) && cancelReason != null) {
                appointment.setCancelReason(cancelReason);
            }
            
            return appointmentRepository.save(appointment);
        }
        return null;
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        appointmentRepository.deleteById(id);
    }
}