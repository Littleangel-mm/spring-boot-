package com.example.treehole.controller;

import com.example.treehole.model.entity.Message;
import com.example.treehole.model.entity.User;
import com.example.treehole.service.MessageService;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/messages")
@RequiredArgsConstructor
public class MessageController {

    private final MessageService messageService;
    private final UserService userService;

    /**
     * 创建新消息
     */
    @PostMapping
    public ResponseEntity<?> createMessage(@RequestBody Message message, @RequestParam Long userId) {
        try {
            Optional<User> userOpt = userService.findById(userId);
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("用户不存在");
            }
            
            message.setUser(userOpt.get());
            message.setCreateTime(LocalDateTime.now());
            message.setIsReplied(false);
            
            Message savedMessage = messageService.save(message);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedMessage);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("创建消息失败: " + e.getMessage());
        }
    }

    /**
     * 获取消息详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getMessageById(@PathVariable Long id) {
        Optional<Message> messageOpt = messageService.findById(id);
        if (messageOpt.isPresent()) {
            return ResponseEntity.ok(messageOpt.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("消息不存在");
        }
    }

    /**
     * 获取用户发送的消息列表
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getMessagesByUserId(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createTime"));
        Page<Message> messages = messageService.findByUserId(userId, pageable);
        return ResponseEntity.ok(messages);
    }

    /**
     * 获取回复用户的消息列表
     */
    @GetMapping("/reply-user/{replyUserId}")
    public ResponseEntity<?> getMessagesByReplyUserId(
            @PathVariable Long replyUserId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createTime"));
        Page<Message> messages = messageService.findByReplyUserId(replyUserId, pageable);
        return ResponseEntity.ok(messages);
    }

    /**
     * 统计未回复消息数量
     */
    @GetMapping("/count/unreplied")
    public ResponseEntity<?> countUnrepliedMessages() {
        int count = messageService.countUnrepliedMessages();
        Map<String, Integer> result = new HashMap<>();
        result.put("count", count);
        return ResponseEntity.ok(result);
    }

    /**
     * 统计特定用户未回复消息数量
     */
    @GetMapping("/count/unreplied/user/{userId}")
    public ResponseEntity<?> countUnrepliedMessagesByUserId(@PathVariable Long userId) {
        int count = messageService.countUnrepliedMessagesByUserId(userId);
        Map<String, Integer> result = new HashMap<>();
        result.put("count", count);
        return ResponseEntity.ok(result);
    }

    /**
     * 删除消息
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteMessage(@PathVariable Long id) {
        try {
            Optional<Message> messageOpt = messageService.findById(id);
            if (messageOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("消息不存在");
            }
            
            messageService.deleteById(id);
            return ResponseEntity.ok("消息已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("删除消息失败: " + e.getMessage());
        }
    }

    /**
     * 回复消息
     */
    @PutMapping("/{id}/reply")
    public ResponseEntity<?> replyMessage(
            @PathVariable Long id,
            @RequestParam String replyContent,
            @RequestParam Long replyUserId) {
        try {
            Optional<Message> messageOpt = messageService.findById(id);
            if (messageOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("消息不存在");
            }
            
            Optional<User> replyUserOpt = userService.findById(replyUserId);
            if (replyUserOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("回复用户不存在");
            }
            
            Message repliedMessage = messageService.reply(id, replyContent, replyUserId);
            return ResponseEntity.ok(repliedMessage);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("回复消息失败: " + e.getMessage());
        }
    }
}