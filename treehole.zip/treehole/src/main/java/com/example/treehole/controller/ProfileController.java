package com.example.treehole.controller;

import com.example.treehole.model.entity.Article;
import com.example.treehole.model.entity.Comment;
import com.example.treehole.model.entity.Consultation;
import com.example.treehole.model.entity.Post;
import com.example.treehole.model.entity.PsychInfo;
import com.example.treehole.model.entity.User;
import com.example.treehole.model.entity.UserFavorite;
import com.example.treehole.repository.ArticleRepository;
import com.example.treehole.repository.CommentRepository;
import com.example.treehole.repository.ConsultationRepository;
import com.example.treehole.repository.PostRepository;
import com.example.treehole.repository.UserFavoriteRepository;
import com.example.treehole.service.ConsultationService;
import com.example.treehole.service.PsychInfoService;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/profile")
@RequiredArgsConstructor
public class ProfileController {
    
    private final UserService userService;
    private final ArticleRepository articleRepository;
    private final PostRepository postRepository;
    private final CommentRepository commentRepository;
    private final UserFavoriteRepository userFavoriteRepository;
    private final ConsultationRepository consultationRepository;
    private final ConsultationService consultationService;
    private final PsychInfoService psychInfoService;
    
    /**
     * 获取用户基本信息
     */
    @GetMapping("/{userId}")
    public ResponseEntity<?> getUserProfile(@PathVariable Long userId) {
        Optional<User> userOpt = userService.findById(userId);
        if (userOpt.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        User user = userOpt.get();
        user.setPassword(null); // 不返回密码
        
        return ResponseEntity.ok(user);
    }
    
    /**
     * 获取用户统计信息
     */
    @GetMapping("/{userId}/statistics")
    public ResponseEntity<?> getUserStatistics(@PathVariable Long userId) {
        // 检查用户是否存在
        if (!userService.findById(userId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        Map<String, Object> statistics = new HashMap<>();
        
        // 文章统计
        Pageable pageable = PageRequest.of(0, 1);
        Page<Article> articles = articleRepository.findByAuthorId(userId, pageable);
        statistics.put("articleCount", articles.getTotalElements());
        
        // 帖子统计
        Page<Post> posts = postRepository.findByUserId(userId, pageable);
        statistics.put("postCount", posts.getTotalElements());
        
        // 评论统计
        Page<Comment> comments = commentRepository.findByUserId(userId, pageable);
        statistics.put("commentCount", comments.getTotalElements());
        
        // 收藏统计
        Page<UserFavorite> favorites = userFavoriteRepository.findByUserId(userId, pageable);
        statistics.put("favoriteCount", favorites.getTotalElements());
        
        // 咨询统计（如果是学生）
        Page<Consultation> studentConsultations = consultationRepository.findByStudentId(userId, pageable);
        statistics.put("studentConsultationCount", studentConsultations.getTotalElements());
        
        // 咨询统计（如果是教师）
        Page<Consultation> teacherConsultations = consultationRepository.findByTeacherId(userId, pageable);
        statistics.put("teacherConsultationCount", teacherConsultations.getTotalElements());
        
        // 检查是否是心理咨询师
        Optional<PsychInfo> psychInfoOpt = psychInfoService.findByUserId(userId);
        statistics.put("isPsychologist", psychInfoOpt.isPresent());
        
        return ResponseEntity.ok(statistics);
    }
    
    /**
     * 获取用户文章列表
     */
    @GetMapping("/{userId}/articles")
    public ResponseEntity<?> getUserArticles(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        
        // 检查用户是否存在
        if (!userService.findById(userId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        Sort sort = direction.equalsIgnoreCase("asc") ? 
                Sort.by(sortBy).ascending() : 
                Sort.by(sortBy).descending();
        
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Article> articles = articleRepository.findByAuthorId(userId, pageable);
        
        return ResponseEntity.ok(articles);
    }
    
    /**
     * 获取用户帖子列表
     */
    @GetMapping("/{userId}/posts")
    public ResponseEntity<?> getUserPosts(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        
        // 检查用户是否存在
        if (!userService.findById(userId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        Sort sort = direction.equalsIgnoreCase("asc") ? 
                Sort.by(sortBy).ascending() : 
                Sort.by(sortBy).descending();
        
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Post> posts = postRepository.findByUserId(userId, pageable);
        
        return ResponseEntity.ok(posts);
    }
    
    /**
     * 获取用户评论列表
     */
    @GetMapping("/{userId}/comments")
    public ResponseEntity<?> getUserComments(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        
        // 检查用户是否存在
        if (!userService.findById(userId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        Sort sort = direction.equalsIgnoreCase("asc") ? 
                Sort.by(sortBy).ascending() : 
                Sort.by(sortBy).descending();
        
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Comment> comments = commentRepository.findByUserId(userId, pageable);
        
        return ResponseEntity.ok(comments);
    }
    
    /**
     * 获取用户收藏列表
     */
    @GetMapping("/{userId}/favorites")
    public ResponseEntity<?> getUserFavorites(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        
        // 检查用户是否存在
        if (!userService.findById(userId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        Sort sort = direction.equalsIgnoreCase("asc") ? 
                Sort.by(sortBy).ascending() : 
                Sort.by(sortBy).descending();
        
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<UserFavorite> favorites = userFavoriteRepository.findByUserId(userId, pageable);
        
        return ResponseEntity.ok(favorites);
    }
    
    /**
     * 获取用户咨询会话列表（作为学生）
     */
    @GetMapping("/{userId}/consultations/student")
    public ResponseEntity<?> getStudentConsultations(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        
        // 检查用户是否存在
        if (!userService.findById(userId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        Sort sort = direction.equalsIgnoreCase("asc") ? 
                Sort.by(sortBy).ascending() : 
                Sort.by(sortBy).descending();
        
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Consultation> consultations = consultationService.findByStudentId(userId, pageable);
        
        return ResponseEntity.ok(consultations);
    }
    
    /**
     * 获取用户咨询会话列表（作为教师）
     */
    @GetMapping("/{userId}/consultations/teacher")
    public ResponseEntity<?> getTeacherConsultations(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        
        // 检查用户是否存在
        if (!userService.findById(userId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        Sort sort = direction.equalsIgnoreCase("asc") ? 
                Sort.by(sortBy).ascending() : 
                Sort.by(sortBy).descending();
        
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Consultation> consultations = consultationService.findByTeacherId(userId, pageable);
        
        return ResponseEntity.ok(consultations);
    }
    
    /**
     * 获取用户心理咨询师信息（如果有）
     */
    @GetMapping("/{userId}/psych-info")
    public ResponseEntity<?> getUserPsychInfo(@PathVariable Long userId) {
        // 检查用户是否存在
        if (!userService.findById(userId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        Optional<PsychInfo> psychInfoOpt = psychInfoService.findByUserId(userId);
        if (psychInfoOpt.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "该用户没有心理咨询师信息");
        }
        
        return ResponseEntity.ok(psychInfoOpt.get());
    }
}