package com.example.treehole.controller;

import com.example.treehole.model.entity.Article;
import com.example.treehole.model.entity.Post;
import com.example.treehole.model.entity.PsychInfo;
import com.example.treehole.model.entity.User;
import com.example.treehole.model.entity.UserFavorite;
import com.example.treehole.service.ArticleService;
import com.example.treehole.service.PostService;
import com.example.treehole.service.PsychInfoService;
import com.example.treehole.service.UserFavoriteService;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/favorites")
@RequiredArgsConstructor
public class UserFavoriteController {
    
    private final UserFavoriteService userFavoriteService;
    private final UserService userService;
    private final ArticleService articleService;
    private final PostService postService;
    private final PsychInfoService psychInfoService;
    
    /**
     * 获取用户收藏列表
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<Page<UserFavorite>> getUserFavorites(
            @PathVariable Long userId,
            @PageableDefault(size = 10, sort = "createTime", direction = Sort.Direction.DESC) Pageable pageable) {
        
        // 检查用户是否存在
        if (!userService.findById(userId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        Page<UserFavorite> favorites = userFavoriteService.findByUserId(userId, pageable);
        return ResponseEntity.ok(favorites);
    }
    
    /**
     * 添加文章收藏
     */
    @PostMapping("/article")
    public ResponseEntity<UserFavorite> addArticleFavorite(
            @RequestParam Long userId,
            @RequestParam Long articleId) {
        
        // 检查用户是否存在
        User user = userService.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在"));
        
        // 检查文章是否存在
        Article article = articleService.findById(articleId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "文章不存在"));
        
        // 检查是否已收藏
        if (userFavoriteService.existsByUserIdAndArticleId(userId, articleId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "已收藏该文章");
        }
        
        // 创建收藏
        UserFavorite favorite = new UserFavorite();
        favorite.setUser(user);
        favorite.setArticle(article);
        
        return ResponseEntity.status(HttpStatus.CREATED).body(userFavoriteService.addFavorite(favorite));
    }
    
    /**
     * 添加帖子收藏
     */
    @PostMapping("/post")
    public ResponseEntity<UserFavorite> addPostFavorite(
            @RequestParam Long userId,
            @RequestParam Long postId) {
        
        // 检查用户是否存在
        User user = userService.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在"));
        
        // 检查帖子是否存在
        Post post = postService.findById(postId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "帖子不存在"));
        
        // 检查是否已收藏
        if (userFavoriteService.existsByUserIdAndPostId(userId, postId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "已收藏该帖子");
        }
        
        // 创建收藏
        UserFavorite favorite = new UserFavorite();
        favorite.setUser(user);
        favorite.setPost(post);
        
        return ResponseEntity.status(HttpStatus.CREATED).body(userFavoriteService.addFavorite(favorite));
    }
    
    /**
     * 添加心理资讯收藏
     */
    @PostMapping("/psych-info")
    public ResponseEntity<UserFavorite> addPsychInfoFavorite(
            @RequestParam Long userId,
            @RequestParam Long psychInfoId) {
        
        // 检查用户是否存在
        User user = userService.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在"));
        
        // 检查心理资讯是否存在
        PsychInfo psychInfo = psychInfoService.findById(psychInfoId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "心理资讯不存在"));
        
        // 检查是否已收藏
        if (userFavoriteService.existsByUserIdAndPsychInfoId(userId, psychInfoId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "已收藏该心理资讯");
        }
        
        // 创建收藏
        UserFavorite favorite = new UserFavorite();
        favorite.setUser(user);
        favorite.setPsychInfo(psychInfo);
        
        return ResponseEntity.status(HttpStatus.CREATED).body(userFavoriteService.addFavorite(favorite));
    }
    
    /**
     * 检查用户是否已收藏文章
     */
    @GetMapping("/check/article")
    public ResponseEntity<Map<String, Boolean>> checkArticleFavorite(
            @RequestParam Long userId,
            @RequestParam Long articleId) {
        
        boolean isFavorited = userFavoriteService.existsByUserIdAndArticleId(userId, articleId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("favorited", isFavorited);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 检查用户是否已收藏帖子
     */
    @GetMapping("/check/post")
    public ResponseEntity<Map<String, Boolean>> checkPostFavorite(
            @RequestParam Long userId,
            @RequestParam Long postId) {
        
        boolean isFavorited = userFavoriteService.existsByUserIdAndPostId(userId, postId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("favorited", isFavorited);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 检查用户是否已收藏心理资讯
     */
    @GetMapping("/check/psych-info")
    public ResponseEntity<Map<String, Boolean>> checkPsychInfoFavorite(
            @RequestParam Long userId,
            @RequestParam Long psychInfoId) {
        
        boolean isFavorited = userFavoriteService.existsByUserIdAndPsychInfoId(userId, psychInfoId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("favorited", isFavorited);
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 取消文章收藏
     */
    @DeleteMapping("/article")
    public ResponseEntity<Void> removeArticleFavorite(
            @RequestParam Long userId,
            @RequestParam Long articleId) {
        
        // 检查收藏是否存在
        if (!userFavoriteService.existsByUserIdAndArticleId(userId, articleId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "收藏不存在");
        }
        
        userFavoriteService.removeArticleFavorite(userId, articleId);
        return ResponseEntity.noContent().build();
    }
    
    /**
     * 取消帖子收藏
     */
    @DeleteMapping("/post")
    public ResponseEntity<Void> removePostFavorite(
            @RequestParam Long userId,
            @RequestParam Long postId) {
        
        // 检查收藏是否存在
        if (!userFavoriteService.existsByUserIdAndPostId(userId, postId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "收藏不存在");
        }
        
        userFavoriteService.removePostFavorite(userId, postId);
        return ResponseEntity.noContent().build();
    }
    
    /**
     * 取消心理资讯收藏
     */
    @DeleteMapping("/psych-info")
    public ResponseEntity<Void> removePsychInfoFavorite(
            @RequestParam Long userId,
            @RequestParam Long psychInfoId) {
        
        // 检查收藏是否存在
        if (!userFavoriteService.existsByUserIdAndPsychInfoId(userId, psychInfoId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "收藏不存在");
        }
        
        userFavoriteService.removePsychInfoFavorite(userId, psychInfoId);
        return ResponseEntity.noContent().build();
    }
    
    /**
     * 删除收藏
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFavorite(@PathVariable Long id) {
        // 检查收藏是否存在
        if (!userFavoriteService.findById(id).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "收藏不存在");
        }
        
        userFavoriteService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}