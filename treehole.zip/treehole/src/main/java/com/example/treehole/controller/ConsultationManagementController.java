package com.example.treehole.controller;

import com.example.treehole.model.entity.Consultation;
import com.example.treehole.model.entity.ConsultationMessage;
import com.example.treehole.model.entity.User;
import com.example.treehole.service.ConsultationMessageService;
import com.example.treehole.service.ConsultationService;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 在线咨询管理接口
 */
@RestController
@RequestMapping("/api/admin/consultations")
@RequiredArgsConstructor
public class ConsultationManagementController {

    private final ConsultationService consultationService;
    private final ConsultationMessageService consultationMessageService;
    private final UserService userService;

    /**
     * 获取所有咨询会话（分页）
     */
    @GetMapping
    public ResponseEntity<?> getAllConsultations(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Consultation> consultations = consultationService.findAll(pageable);
            
            return ResponseEntity.ok(consultations);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取咨询会话列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取咨询会话详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getConsultationDetail(@PathVariable Long id) {
        try {
            Optional<Consultation> consultationOpt = consultationService.findById(id);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            return ResponseEntity.ok(consultationOpt.get());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取咨询会话详情失败: " + e.getMessage());
        }
    }

    /**
     * 获取咨询会话的所有消息
     */
    @GetMapping("/{consultationId}/messages")
    public ResponseEntity<?> getConsultationMessages(@PathVariable Long consultationId) {
        try {
            // 验证咨询会话是否存在
            Optional<Consultation> consultationOpt = consultationService.findById(consultationId);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            List<ConsultationMessage> messages = consultationMessageService.findByConsultationId(consultationId);
            return ResponseEntity.ok(messages);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取咨询消息失败: " + e.getMessage());
        }
    }

    /**
     * 关闭咨询会话
     */
    @PutMapping("/{id}/close")
    public ResponseEntity<?> closeConsultation(@PathVariable Long id) {
        try {
            Optional<Consultation> consultationOpt = consultationService.findById(id);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            Consultation closedConsultation = consultationService.closeConsultation(id);
            return ResponseEntity.ok(closedConsultation);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("关闭咨询会话失败: " + e.getMessage());
        }
    }

    /**
     * 更新咨询会话状态
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateConsultationStatus(
            @PathVariable Long id, 
            @RequestParam String status) {
        try {
            Optional<Consultation> consultationOpt = consultationService.findById(id);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            // 验证状态值是否有效
            if (!status.equals("ONGOING") && !status.equals("CLOSED")) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("无效的状态值，只能为 ONGOING 或 CLOSED");
            }
            
            Consultation updatedConsultation = consultationService.updateStatus(id, status);
            return ResponseEntity.ok(updatedConsultation);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("更新咨询会话状态失败: " + e.getMessage());
        }
    }

    /**
     * 删除咨询会话
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteConsultation(@PathVariable Long id) {
        try {
            Optional<Consultation> consultationOpt = consultationService.findById(id);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            consultationService.deleteById(id);
            return ResponseEntity.ok("咨询会话已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("删除咨询会话失败: " + e.getMessage());
        }
    }

    /**
     * 删除咨询消息
     */
    @DeleteMapping("/messages/{messageId}")
    public ResponseEntity<?> deleteConsultationMessage(@PathVariable Long messageId) {
        try {
            Optional<ConsultationMessage> messageOpt = consultationMessageService.findById(messageId);
            if (messageOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("消息不存在");
            }
            
            consultationMessageService.deleteById(messageId);
            return ResponseEntity.ok("消息已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("删除消息失败: " + e.getMessage());
        }
    }

    /**
     * 获取咨询统计信息
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getConsultationStatistics() {
        try {
            // 获取所有咨询会话
            Page<Consultation> allConsultations = consultationService.findAll(Pageable.unpaged());
            
            // 计算统计信息
            long totalConsultations = allConsultations.getTotalElements();
            
            // 按状态分类
            List<Consultation> consultationList = allConsultations.getContent();
            long ongoingConsultations = consultationList.stream()
                    .filter(c -> "ONGOING".equals(c.getStatus()))
                    .count();
            long closedConsultations = consultationList.stream()
                    .filter(c -> "CLOSED".equals(c.getStatus()))
                    .count();
            
            // 构建统计结果
            Map<String, Object> statistics = new HashMap<>();
            statistics.put("totalConsultations", totalConsultations);
            statistics.put("ongoingConsultations", ongoingConsultations);
            statistics.put("closedConsultations", closedConsultations);
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取咨询统计信息失败: " + e.getMessage());
        }
    }

    /**
     * 获取未读消息统计
     */
    @GetMapping("/unread-messages")
    public ResponseEntity<?> getUnreadMessagesStatistics() {
        try {
            // 获取所有咨询会话
            Page<Consultation> allConsultations = consultationService.findAll(Pageable.unpaged());
            List<Consultation> consultationList = allConsultations.getContent();
            
            // 统计每个会话的未读消息
            Map<Long, Long> unreadMessagesByConsultation = new HashMap<>();
            long totalUnreadMessages = 0;
            
            for (Consultation consultation : consultationList) {
                List<ConsultationMessage> messages = consultationMessageService.findByConsultationId(consultation.getId());
                long unreadCount = messages.stream()
                        .filter(m -> !m.getIsRead())
                        .count();
                
                if (unreadCount > 0) {
                    unreadMessagesByConsultation.put(consultation.getId(), unreadCount);
                    totalUnreadMessages += unreadCount;
                }
            }
            
            // 构建统计结果
            Map<String, Object> statistics = new HashMap<>();
            statistics.put("totalUnreadMessages", totalUnreadMessages);
            statistics.put("unreadMessagesByConsultation", unreadMessagesByConsultation);
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取未读消息统计失败: " + e.getMessage());
        }
    }

    /**
     * 批量标记消息为已读
     */
    @PutMapping("/messages/batch-read")
    public ResponseEntity<?> batchMarkMessagesAsRead(@RequestBody List<Long> messageIds) {
        try {
            if (messageIds == null || messageIds.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("消息ID列表不能为空");
            }
            
            List<ConsultationMessage> updatedMessages = messageIds.stream()
                    .map(consultationMessageService::markAsRead)
                    .filter(message -> message != null)
                    .collect(Collectors.toList());
            
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "updatedCount", updatedMessages.size(),
                    "updatedMessages", updatedMessages
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("批量标记消息为已读失败: " + e.getMessage());
        }
    }

    /**
     * 获取按教师分组的咨询会话统计
     */
    @GetMapping("/statistics/by-teacher")
    public ResponseEntity<?> getConsultationStatisticsByTeacher() {
        try {
            // 获取所有咨询会话
            Page<Consultation> allConsultations = consultationService.findAll(Pageable.unpaged());
            List<Consultation> consultationList = allConsultations.getContent();
            
            // 按教师分组统计
            Map<Long, Map<String, Object>> statisticsByTeacher = new HashMap<>();
            
            for (Consultation consultation : consultationList) {
                Long teacherId = consultation.getTeacher().getId();
                
                // 初始化教师统计信息
                if (!statisticsByTeacher.containsKey(teacherId)) {
                    Map<String, Object> teacherStats = new HashMap<>();
                    teacherStats.put("teacherId", teacherId);
                    teacherStats.put("teacherName", consultation.getTeacher().getUsername());
                    teacherStats.put("totalConsultations", 0);
                    teacherStats.put("ongoingConsultations", 0);
                    teacherStats.put("closedConsultations", 0);
                    statisticsByTeacher.put(teacherId, teacherStats);
                }
                
                // 更新统计信息
                Map<String, Object> teacherStats = statisticsByTeacher.get(teacherId);
                teacherStats.put("totalConsultations", (int)teacherStats.get("totalConsultations") + 1);
                
                if ("ONGOING".equals(consultation.getStatus())) {
                    teacherStats.put("ongoingConsultations", (int)teacherStats.get("ongoingConsultations") + 1);
                } else if ("CLOSED".equals(consultation.getStatus())) {
                    teacherStats.put("closedConsultations", (int)teacherStats.get("closedConsultations") + 1);
                }
            }
            
            return ResponseEntity.ok(statisticsByTeacher.values());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取按教师分组的咨询统计失败: " + e.getMessage());
        }
    }
}