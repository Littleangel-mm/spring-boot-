package com.example.treehole.controller;

import com.example.treehole.model.entity.Article;
import com.example.treehole.model.entity.Category;
import com.example.treehole.service.ArticleService;
import com.example.treehole.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/admin/categories")
@RequiredArgsConstructor
public class CategoryManagementController {

    private final CategoryService categoryService;
    private final ArticleService articleService;

    /**
     * 获取所有分类（分页）
     */
    @GetMapping
    public ResponseEntity<?> getAllCategories(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "sort") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Category> categories = categoryService.findAll(pageable);
            
            return ResponseEntity.ok(categories);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取分类列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取所有分类（不分页，用于下拉选择）
     */
    @GetMapping("/all")
    public ResponseEntity<?> getAllCategoriesForSelect() {
        try {
            List<Category> categories = categoryService.findAllSorted();
            return ResponseEntity.ok(categories);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取分类列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取分类详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getCategoryById(@PathVariable Long id) {
        try {
            Optional<Category> categoryOpt = categoryService.findById(id);
            if (categoryOpt.isPresent()) {
                return ResponseEntity.ok(categoryOpt.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分类不存在");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取分类详情失败: " + e.getMessage());
        }
    }

    /**
     * 创建分类
     */
    @PostMapping
    public ResponseEntity<?> createCategory(@RequestBody Category category) {
        try {
            // 检查分类名称是否已存在
            if (categoryService.existsByName(category.getName())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("分类名称已存在");
            }
            
            // 设置创建时间和更新时间
            LocalDateTime now = LocalDateTime.now();
            category.setCreateTime(now);
            category.setUpdateTime(now);
            
            // 如果没有设置排序值，默认为0
            if (category.getSort() == null) {
                category.setSort(0);
            }
            
            // 如果没有设置启用状态，默认为启用
            if (category.getEnabled() == null) {
                category.setEnabled(true);
            }
            
            Category savedCategory = categoryService.save(category);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedCategory);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("创建分类失败: " + e.getMessage());
        }
    }

    /**
     * 更新分类
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateCategory(@PathVariable Long id, @RequestBody Category category) {
        try {
            Optional<Category> categoryOpt = categoryService.findById(id);
            if (categoryOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分类不存在");
            }
            
            Category existingCategory = categoryOpt.get();
            
            // 检查分类名称是否已存在（排除当前分类）
            if (!existingCategory.getName().equals(category.getName()) && 
                    categoryService.existsByName(category.getName())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("分类名称已存在");
            }
            
            // 更新分类信息
            existingCategory.setName(category.getName());
            existingCategory.setDescription(category.getDescription());
            existingCategory.setSort(category.getSort());
            existingCategory.setUpdateTime(LocalDateTime.now());
            
            Category updatedCategory = categoryService.save(existingCategory);
            return ResponseEntity.ok(updatedCategory);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新分类失败: " + e.getMessage());
        }
    }

    /**
     * 删除分类
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCategory(@PathVariable Long id) {
        try {
            Optional<Category> categoryOpt = categoryService.findById(id);
            if (categoryOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分类不存在");
            }
            
            // 检查分类下是否有文章
            Pageable pageable = PageRequest.of(0, 1);
            Page<Article> articles = articleService.findByCategoryId(id, pageable);
            if (articles.getTotalElements() > 0) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("该分类下存在文章，无法删除");
            }
            
            categoryService.deleteById(id);
            return ResponseEntity.ok("分类已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("删除分类失败: " + e.getMessage());
        }
    }

    /**
     * 启用/禁用分类
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateCategoryStatus(
            @PathVariable Long id,
            @RequestParam boolean enabled) {
        try {
            Optional<Category> categoryOpt = categoryService.findById(id);
            if (categoryOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分类不存在");
            }
            
            Category category = categoryOpt.get();
            category.setEnabled(enabled);
            category.setUpdateTime(LocalDateTime.now());
            
            Category updatedCategory = categoryService.save(category);
            
            Map<String, Object> result = new HashMap<>();
            result.put("message", enabled ? "分类已启用" : "分类已禁用");
            result.put("category", updatedCategory);
            
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新分类状态失败: " + e.getMessage());
        }
    }

    /**
     * 调整分类排序
     */
    @PutMapping("/{id}/sort")
    public ResponseEntity<?> updateCategorySort(
            @PathVariable Long id,
            @RequestParam int sort) {
        try {
            Optional<Category> categoryOpt = categoryService.findById(id);
            if (categoryOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分类不存在");
            }
            
            Category category = categoryOpt.get();
            category.setSort(sort);
            category.setUpdateTime(LocalDateTime.now());
            
            Category updatedCategory = categoryService.save(category);
            return ResponseEntity.ok(updatedCategory);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新分类排序失败: " + e.getMessage());
        }
    }

    /**
     * 获取分类统计信息
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getCategoryStatistics() {
        try {
            List<Category> allCategories = categoryService.findAll();
            long totalCategories = allCategories.size();
            long enabledCategories = allCategories.stream().filter(Category::getEnabled).count();
            long disabledCategories = totalCategories - enabledCategories;
            
            Map<String, Object> statistics = new HashMap<>();
            statistics.put("totalCategories", totalCategories);
            statistics.put("enabledCategories", enabledCategories);
            statistics.put("disabledCategories", disabledCategories);
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取分类统计信息失败: " + e.getMessage());
        }
    }
}