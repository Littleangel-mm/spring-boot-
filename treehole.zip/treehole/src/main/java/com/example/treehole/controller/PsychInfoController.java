package com.example.treehole.controller;

import com.example.treehole.model.entity.PsychInfo;
import com.example.treehole.service.PsychInfoService;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/psych-info")
@RequiredArgsConstructor
public class PsychInfoController {

    private final PsychInfoService psychInfoService;
    private final UserService userService;

    /**
     * 创建心理咨询师信息
     */
    @PostMapping
    public ResponseEntity<?> createPsychInfo(@RequestBody PsychInfo psychInfo) {
        try {
            // 验证用户是否存在
            if (psychInfo.getUserId() == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("用户ID不能为空");
            }
            
            if (!userService.findById(psychInfo.getUserId()).isPresent()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("用户不存在");
            }
            
            // 检查该用户是否已有心理咨询师信息
            Optional<PsychInfo> existingInfo = psychInfoService.findByUserId(psychInfo.getUserId());
            if (existingInfo.isPresent()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("该用户已有心理咨询师信息");
            }
            
            // 设置初始值
            psychInfo.setCreateTime(LocalDateTime.now());
            psychInfo.setUpdateTime(LocalDateTime.now());
            psychInfo.setViewCount(0);
            psychInfo.setIsTop(false);
            psychInfo.setStatus(true);
            psychInfo.setApproved(false); // 默认未审核
            
            // 保存心理咨询师信息
            PsychInfo savedPsychInfo = psychInfoService.save(psychInfo);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedPsychInfo);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("创建心理咨询师信息失败: " + e.getMessage());
        }
    }

    /**
     * 获取心理咨询师信息详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getPsychInfo(@PathVariable Long id) {
        try {
            Optional<PsychInfo> psychInfoOpt = psychInfoService.findById(id);
            if (psychInfoOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("心理咨询师信息不存在");
            }
            
            return ResponseEntity.ok(psychInfoOpt.get());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取心理咨询师信息失败: " + e.getMessage());
        }
    }

    /**
     * 根据用户ID获取心理咨询师信息
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getPsychInfoByUserId(@PathVariable Long userId) {
        try {
            Optional<PsychInfo> psychInfoOpt = psychInfoService.findByUserId(userId);
            if (psychInfoOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("该用户的心理咨询师信息不存在");
            }
            
            return ResponseEntity.ok(psychInfoOpt.get());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取心理咨询师信息失败: " + e.getMessage());
        }
    }

    /**
     * 更新心理咨询师信息
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updatePsychInfo(@PathVariable Long id, @RequestBody PsychInfo updatedPsychInfo) {
        try {
            Optional<PsychInfo> psychInfoOpt = psychInfoService.findById(id);
            if (psychInfoOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("心理咨询师信息不存在");
            }
            
            PsychInfo existingPsychInfo = psychInfoOpt.get();
            
            // 更新可修改的字段
            if (updatedPsychInfo.getTitle() != null) {
                existingPsychInfo.setTitle(updatedPsychInfo.getTitle());
            }
            if (updatedPsychInfo.getContent() != null) {
                existingPsychInfo.setContent(updatedPsychInfo.getContent());
            }
            if (updatedPsychInfo.getCoverImage() != null) {
                existingPsychInfo.setCoverImage(updatedPsychInfo.getCoverImage());
            }
            
            // 更新时间
            existingPsychInfo.setUpdateTime(LocalDateTime.now());
            
            // 保存更新后的心理咨询师信息
            PsychInfo savedPsychInfo = psychInfoService.save(existingPsychInfo);
            return ResponseEntity.ok(savedPsychInfo);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("更新心理咨询师信息失败: " + e.getMessage());
        }
    }

    /**
     * 删除心理咨询师信息
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePsychInfo(@PathVariable Long id) {
        try {
            Optional<PsychInfo> psychInfoOpt = psychInfoService.findById(id);
            if (psychInfoOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("心理咨询师信息不存在");
            }
            
            psychInfoService.deleteById(id);
            return ResponseEntity.ok("心理咨询师信息已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("删除心理咨询师信息失败: " + e.getMessage());
        }
    }

    /**
     * 获取所有心理咨询师信息（分页）
     */
    @GetMapping
    public ResponseEntity<?> getAllPsychInfo(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<PsychInfo> psychInfos = psychInfoService.findAll(pageable);
            
            return ResponseEntity.ok(psychInfos);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取心理咨询师信息列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取所有已审核的心理咨询师信息
     */
    @GetMapping("/approved")
    public ResponseEntity<?> getAllApprovedPsychInfo() {
        try {
            List<PsychInfo> psychInfos = psychInfoService.findAllApproved();
            return ResponseEntity.ok(psychInfos);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取已审核的心理咨询师信息失败: " + e.getMessage());
        }
    }

    /**
     * 审核心理咨询师信息
     */
    @PutMapping("/{id}/approve")
    public ResponseEntity<?> approvePsychInfo(@PathVariable Long id, @RequestParam boolean approved) {
        try {
            Optional<PsychInfo> psychInfoOpt = psychInfoService.findById(id);
            if (psychInfoOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("心理咨询师信息不存在");
            }
            
            boolean result = psychInfoService.approve(id, approved);
            if (result) {
                return ResponseEntity.ok("心理咨询师信息审核状态已更新");
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("更新审核状态失败");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("审核心理咨询师信息失败: " + e.getMessage());
        }
    }
}