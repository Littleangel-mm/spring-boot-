package com.example.treehole.service;

import com.example.treehole.model.entity.Banner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface BannerService {
    
    /**
     * 保存Banner（新增或更新）
     */
    Banner save(Banner banner);
    
    /**
     * 根据ID查找Banner
     */
    Optional<Banner> findById(Long id);
    
    /**
     * 分页查询所有Banner
     */
    Page<Banner> findAll(Pageable pageable);
    
    /**
     * 查询所有启用的Banner并按排序字段升序排列
     */
    List<Banner> findAllEnabledAndSorted();
    
    /**
     * 根据ID删除Banner
     */
    void deleteById(Long id);
    
    /**
     * 更新Banner状态（启用/禁用）
     */
    Banner updateStatus(Long id, Boolean enabled);
    
    /**
     * 更新Banner排序
     */
    Banner updateSort(Long id, Integer sort);
}