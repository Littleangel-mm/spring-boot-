package com.example.treehole.service.impl;

import com.example.treehole.model.entity.User;
import com.example.treehole.repository.UserRepository;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    
    @Override
    @Transactional
    public User register(User user) {
        // 检查用户名是否已存在
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("用户名已存在");
        }
        
        // 设置创建时间和更新时间
        LocalDateTime now = LocalDateTime.now();
        user.setCreateTime(now);
        user.setUpdateTime(now);
        
        // 加密密码
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        
        // 如果角色为空，设置默认角色为学生
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("student");
        }
        
        // 默认启用账户
        user.setEnabled(true);
        
        return userRepository.save(user);
    }
    
    @Override
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }
    
    @Override
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    @Override
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    @Override
    public Optional<User> findByPhone(String phone) {
        return userRepository.findByPhone(phone);
    }
    
    @Override
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }
    
    @Override
    @Transactional
    public User save(User user) {
        // 如果是更新用户，设置更新时间
        if (user.getId() != null) {
            user.setUpdateTime(LocalDateTime.now());
            
            // 如果密码字段不为空，且不是加密后的格式，则进行加密
            if (user.getPassword() != null && !user.getPassword().startsWith("$2a$")) {
                user.setPassword(passwordEncoder.encode(user.getPassword()));
            }
        }
        return userRepository.save(user);
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        userRepository.deleteById(id);
    }
    
    @Override
    public Page<User> findAll(Pageable pageable) {
        return userRepository.findAll(pageable);
    }
    
    @Override
    public Page<User> findByRole(String role, Pageable pageable) {
        Page<User> allUsers = userRepository.findAll(pageable);
        List<User> filteredUsers = allUsers.getContent().stream()
                .filter(user -> user.getRole().equals(role))
                .collect(Collectors.toList());
        
        return new PageImpl<>(filteredUsers, pageable, filteredUsers.size());
    }
    
    @Override
    @Transactional
    public boolean updatePassword(Long userId, String oldPassword, String newPassword) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            // 验证旧密码
            if (passwordEncoder.matches(oldPassword, user.getPassword())) {
                // 设置新密码
                user.setPassword(passwordEncoder.encode(newPassword));
                user.setUpdateTime(LocalDateTime.now());
                userRepository.save(user);
                return true;
            }
        }
        return false;
    }
    
    @Override
    @Transactional
    public boolean enableUser(Long userId, boolean enabled) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setEnabled(enabled);
            user.setUpdateTime(LocalDateTime.now());
            userRepository.save(user);
            return true;
        }
        return false;
    }
}