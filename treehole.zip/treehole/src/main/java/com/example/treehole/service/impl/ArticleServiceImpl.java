package com.example.treehole.service.impl;

import com.example.treehole.model.entity.Article;
import com.example.treehole.repository.ArticleRepository;
import com.example.treehole.service.ArticleService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ArticleServiceImpl implements ArticleService {
    
    private final ArticleRepository articleRepository;
    
    @Override
    @Transactional
    public Article save(Article article) {
        if (article.getId() == null) {
            // 新文章
            LocalDateTime now = LocalDateTime.now();
            article.setCreateTime(now);
            article.setUpdateTime(now);
            article.setViewCount(0);
        } else {
            // 更新文章
            article.setUpdateTime(LocalDateTime.now());
        }
        return articleRepository.save(article);
    }
    
    @Override
    public Optional<Article> findById(Long id) {
        return articleRepository.findById(id);
    }
    
    @Override
    public Page<Article> findAll(Pageable pageable) {
        return articleRepository.findAll(pageable);
    }
    
    @Override
    public Page<Article> findByCategoryId(Long categoryId, Pageable pageable) {
        return articleRepository.findByCategoryId(categoryId, pageable);
    }
    
    @Override
    public Page<Article> findByAuthorId(Long authorId, Pageable pageable) {
        return articleRepository.findByAuthorId(authorId, pageable);
    }
    
    @Override
    public Page<Article> search(String keyword, Pageable pageable) {
        return articleRepository.findByTitleContainingOrContentContaining(keyword, keyword, pageable);
    }
    
    @Override
    public List<Article> findTopViewed(int limit) {
        // 默认返回前5篇浏览量最高的文章
        if (limit <= 0) {
            limit = 5;
        }
        return articleRepository.findTop5ByOrderByViewCountDesc().subList(0, Math.min(limit, 5));
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        articleRepository.deleteById(id);
    }
    
    @Override
    @Transactional
    public Article incrementViewCount(Long id) {
        Optional<Article> articleOpt = articleRepository.findById(id);
        if (articleOpt.isPresent()) {
            Article article = articleOpt.get();
            article.setViewCount(article.getViewCount() + 1);
            return articleRepository.save(article);
        }
        return null;
    }
}