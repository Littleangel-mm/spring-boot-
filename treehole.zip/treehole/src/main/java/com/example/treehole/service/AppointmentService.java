package com.example.treehole.service;

import com.example.treehole.model.entity.Appointment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface AppointmentService {
    
    /**
     * 保存预约信息（新增或更新）
     */
    Appointment save(Appointment appointment);
    
    /**
     * 根据ID查找预约信息
     */
    Optional<Appointment> findById(Long id);
    
    /**
     * 分页查询所有预约信息
     */
    Page<Appointment> findAll(Pageable pageable);
    
    /**
     * 根据学生ID查询预约信息
     */
    Page<Appointment> findByStudentId(Long studentId, Pageable pageable);
    
    /**
     * 根据教师ID查询预约信息
     */
    Page<Appointment> findByTeacherId(Long teacherId, Pageable pageable);
    
    /**
     * 根据状态查询预约信息
     */
    Page<Appointment> findByStatus(String status, Pageable pageable);
    
    /**
     * 根据教师ID和时间范围查询预约信息
     */
    List<Appointment> findByTeacherIdAndTimeBetween(Long teacherId, LocalDateTime start, LocalDateTime end);
    
    /**
     * 更新预约状态
     */
    Appointment updateStatus(Long id, String status, String cancelReason);
    
    /**
     * 删除预约信息
     */
    void deleteById(Long id);
}