package com.example.treehole.service.impl;

import com.example.treehole.model.entity.Banner;
import com.example.treehole.repository.BannerRepository;
import com.example.treehole.service.BannerService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class BannerServiceImpl implements BannerService {
    
    private final BannerRepository bannerRepository;
    
    @Override
    @Transactional
    public Banner save(Banner banner) {
        LocalDateTime now = LocalDateTime.now();
        if (banner.getId() == null) {
            // 新增Banner
            banner.setCreateTime(now);
        }
        banner.setUpdateTime(now);
        return bannerRepository.save(banner);
    }
    
    @Override
    public Optional<Banner> findById(Long id) {
        return bannerRepository.findById(id);
    }
    
    @Override
    public Page<Banner> findAll(Pageable pageable) {
        return bannerRepository.findAll(pageable);
    }
    
    @Override
    public List<Banner> findAllEnabledAndSorted() {
        return bannerRepository.findByEnabledTrueOrderBySortAsc();
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        bannerRepository.deleteById(id);
    }
    
    @Override
    @Transactional
    public Banner updateStatus(Long id, Boolean enabled) {
        Optional<Banner> bannerOpt = bannerRepository.findById(id);
        if (bannerOpt.isPresent()) {
            Banner banner = bannerOpt.get();
            banner.setEnabled(enabled);
            banner.setUpdateTime(LocalDateTime.now());
            return bannerRepository.save(banner);
        }
        return null;
    }
    
    @Override
    @Transactional
    public Banner updateSort(Long id, Integer sort) {
        Optional<Banner> bannerOpt = bannerRepository.findById(id);
        if (bannerOpt.isPresent()) {
            Banner banner = bannerOpt.get();
            banner.setSort(sort);
            banner.setUpdateTime(LocalDateTime.now());
            return bannerRepository.save(banner);
        }
        return null;
    }
}