package com.example.treehole.repository;

import com.example.treehole.model.entity.Zone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ZoneRepository extends JpaRepository<Zone, Long> {
    
    List<Zone> findByOrderBySortAsc();
    
    boolean existsByName(String name);
}