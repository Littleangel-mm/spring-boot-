package com.example.treehole.repository;

import com.example.treehole.model.entity.Consultation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ConsultationRepository extends JpaRepository<Consultation, Long> {
    
    Page<Consultation> findByStudentId(Long studentId, Pageable pageable);
    
    Page<Consultation> findByTeacherId(Long teacherId, Pageable pageable);
}