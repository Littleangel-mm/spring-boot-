package com.example.treehole.controller;

import com.example.treehole.model.entity.Post;
import com.example.treehole.model.entity.Zone;
import com.example.treehole.service.PostService;
import com.example.treehole.service.ZoneService;
import com.example.treehole.util.PageUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * 分区管理接口
 */
@RestController
@RequestMapping("/api/admin/zones")
@RequiredArgsConstructor
public class ZoneManagementController {

    private final ZoneService zoneService;
    private final PostService postService;

    /**
     * 获取所有分区（分页）
     */
    @GetMapping
    public ResponseEntity<?> getAllZones(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "sort") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            List<Zone> zones = zoneService.findAll();
            
            // 使用工具类进行分页
            Page<Zone> zonePage = PageUtil.toPage(zones, pageable);
            
            return ResponseEntity.ok(zonePage);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取分区列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取所有分区（不分页，用于下拉选择）
     */
    @GetMapping("/all")
    public ResponseEntity<?> getAllZonesForSelect() {
        try {
            List<Zone> zones = zoneService.findAllSorted();
            return ResponseEntity.ok(zones);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取分区列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取分区详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getZoneById(@PathVariable Long id) {
        try {
            Optional<Zone> zoneOpt = zoneService.findById(id);
            if (zoneOpt.isPresent()) {
                return ResponseEntity.ok(zoneOpt.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分区不存在");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取分区详情失败: " + e.getMessage());
        }
    }

    /**
     * 创建分区
     */
    @PostMapping
    public ResponseEntity<?> createZone(@RequestBody Zone zone) {
        try {
            // 检查分区名称是否已存在
            if (zoneService.existsByName(zone.getName())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("分区名称已存在");
            }
            
            // 设置创建时间和更新时间
            LocalDateTime now = LocalDateTime.now();
            zone.setCreateTime(now);
            zone.setUpdateTime(now);
            
            // 如果没有设置排序值，默认为0
            if (zone.getSort() == null) {
                zone.setSort(0);
            }
            
            // 如果没有设置启用状态，默认为启用
            if (zone.getEnabled() == null) {
                zone.setEnabled(true);
            }
            
            Zone savedZone = zoneService.save(zone);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedZone);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("创建分区失败: " + e.getMessage());
        }
    }

    /**
     * 更新分区
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateZone(@PathVariable Long id, @RequestBody Zone zone) {
        try {
            Optional<Zone> zoneOpt = zoneService.findById(id);
            if (zoneOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分区不存在");
            }
            
            Zone existingZone = zoneOpt.get();
            
            // 检查分区名称是否已存在（排除当前分区）
            if (!existingZone.getName().equals(zone.getName()) && 
                    zoneService.existsByName(zone.getName())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("分区名称已存在");
            }
            
            // 更新分区信息
            existingZone.setName(zone.getName());
            existingZone.setDescription(zone.getDescription());
            existingZone.setIcon(zone.getIcon());
            existingZone.setSort(zone.getSort());
            existingZone.setUpdateTime(LocalDateTime.now());
            
            Zone updatedZone = zoneService.save(existingZone);
            return ResponseEntity.ok(updatedZone);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新分区失败: " + e.getMessage());
        }
    }

    /**
     * 删除分区
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteZone(@PathVariable Long id) {
        try {
            Optional<Zone> zoneOpt = zoneService.findById(id);
            if (zoneOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分区不存在");
            }
            
            // 检查分区下是否有帖子
            Pageable pageable = PageRequest.of(0, 1);
            Page<Post> posts = postService.findByZoneId(id, pageable);
            if (posts.getTotalElements() > 0) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("该分区下存在帖子，无法删除");
            }
            
            zoneService.deleteById(id);
            return ResponseEntity.ok("分区已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("删除分区失败: " + e.getMessage());
        }
    }

    /**
     * 更新分区状态（启用/禁用）
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateZoneStatus(
            @PathVariable Long id,
            @RequestParam boolean enabled) {
        try {
            Optional<Zone> zoneOpt = zoneService.findById(id);
            if (zoneOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分区不存在");
            }
            
            Zone zone = zoneOpt.get();
            zone.setEnabled(enabled);
            zone.setUpdateTime(LocalDateTime.now());
            
            Zone updatedZone = zoneService.save(zone);
            
            Map<String, Object> result = new HashMap<>();
            result.put("message", enabled ? "分区已启用" : "分区已禁用");
            result.put("zone", updatedZone);
            
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新分区状态失败: " + e.getMessage());
        }
    }

    /**
     * 更新分区排序
     */
    @PutMapping("/{id}/sort")
    public ResponseEntity<?> updateZoneSort(
            @PathVariable Long id,
            @RequestParam int sort) {
        try {
            Optional<Zone> zoneOpt = zoneService.findById(id);
            if (zoneOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("分区不存在");
            }
            
            Zone zone = zoneOpt.get();
            zone.setSort(sort);
            zone.setUpdateTime(LocalDateTime.now());
            
            Zone updatedZone = zoneService.save(zone);
            return ResponseEntity.ok(updatedZone);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新分区排序失败: " + e.getMessage());
        }
    }

    /**
     * 获取分区统计信息
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getZoneStatistics() {
        try {
            List<Zone> zones = zoneService.findAll();
            
            // 计算统计信息
            int totalZones = zones.size();
            long enabledZones = zones.stream().filter(Zone::getEnabled).count();
            long disabledZones = totalZones - enabledZones;
            
            Map<String, Object> statistics = new HashMap<>();
            statistics.put("totalZones", totalZones);
            statistics.put("enabledZones", enabledZones);
            statistics.put("disabledZones", disabledZones);
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取分区统计信息失败: " + e.getMessage());
        }
    }

    /**
     * 获取分区帖子统计
     */
    @GetMapping("/post-statistics")
    public ResponseEntity<?> getZonePostStatistics() {
        try {
            List<Zone> zones = zoneService.findAll();
            Map<Long, Object> zonePostStats = new HashMap<>();
            
            for (Zone zone : zones) {
                // 获取分区下的帖子数量
                Page<Post> posts = postService.findByZoneId(zone.getId(), Pageable.unpaged());
                
                Map<String, Object> stats = new HashMap<>();
                stats.put("zoneId", zone.getId());
                stats.put("zoneName", zone.getName());
                stats.put("postCount", posts.getTotalElements());
                
                zonePostStats.put(zone.getId(), stats);
            }
            
            return ResponseEntity.ok(zonePostStats.values());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取分区帖子统计失败: " + e.getMessage());
        }
    }
}