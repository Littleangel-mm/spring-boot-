package com.example.treehole.service.impl;

import com.example.treehole.model.entity.About;
import com.example.treehole.repository.AboutRepository;
import com.example.treehole.service.AboutService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AboutServiceImpl implements AboutService {
    
    private final AboutRepository aboutRepository;
    
    @Override
    @Transactional
    public About save(About about) {
        LocalDateTime now = LocalDateTime.now();
        if (about.getId() == null) {
            // 新增About
            about.setCreateTime(now);
        }
        about.setUpdateTime(now);
        return aboutRepository.save(about);
    }
    
    @Override
    public Optional<About> findById(Long id) {
        return aboutRepository.findById(id);
    }
    
    @Override
    public Page<About> findAll(Pageable pageable) {
        return aboutRepository.findAll(pageable);
    }
    
    @Override
    public List<About> findAll() {
        return aboutRepository.findAll();
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        aboutRepository.deleteById(id);
    }
}