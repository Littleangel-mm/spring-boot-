package com.example.treehole.controller;

import com.example.treehole.model.entity.Article;
import com.example.treehole.model.entity.Comment;
import com.example.treehole.model.entity.Post;
import com.example.treehole.model.entity.User;
import com.example.treehole.service.ArticleService;
import com.example.treehole.service.CommentService;
import com.example.treehole.service.PostService;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/comments")
@RequiredArgsConstructor
public class CommentController {
    
    private final CommentService commentService;
    private final UserService userService;
    private final ArticleService articleService;
    private final PostService postService;
    
    /**
     * 创建文章评论
     */
    @PostMapping("/article")
    public ResponseEntity<Comment> createArticleComment(
            @RequestParam Long articleId,
            @RequestParam Long userId,
            @RequestParam(required = false) Long parentId,
            @RequestParam String content) {
        
        try {
            // 检查用户是否存在
            User user = userService.findById(userId)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在"));
            
            // 检查文章是否存在
            Article article = articleService.findById(articleId)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "文章不存在"));
            
            // 创建评论
            Comment comment = new Comment();
            comment.setContent(content);
            comment.setUser(user);
            comment.setArticle(article);
            
            // 如果有父评论，设置父评论
            if (parentId != null) {
                Comment parent = commentService.findById(parentId)
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "父评论不存在"));
                comment.setParent(parent);
            }
            
            Comment savedComment = commentService.save(comment);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedComment);
            
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "创建评论失败: " + e.getMessage());
        }
    }
    
    /**
     * 创建帖子评论
     */
    @PostMapping("/post")
    public ResponseEntity<Comment> createPostComment(
            @RequestParam Long postId,
            @RequestParam Long userId,
            @RequestParam(required = false) Long parentId,
            @RequestParam String content) {
        
        try {
            // 检查用户是否存在
            User user = userService.findById(userId)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在"));
            
            // 检查帖子是否存在
            Post post = postService.findById(postId)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "帖子不存在"));
            
            // 创建评论
            Comment comment = new Comment();
            comment.setContent(content);
            comment.setUser(user);
            comment.setPost(post);
            
            // 如果有父评论，设置父评论
            if (parentId != null) {
                Comment parent = commentService.findById(parentId)
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "父评论不存在"));
                comment.setParent(parent);
            }
            
            Comment savedComment = commentService.save(comment);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedComment);
            
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "创建评论失败: " + e.getMessage());
        }
    }
    
    /**
     * 获取评论详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<Comment> getComment(@PathVariable Long id) {
        Optional<Comment> commentOpt = commentService.findById(id);
        if (commentOpt.isPresent()) {
            return ResponseEntity.ok(commentOpt.get());
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "评论不存在");
        }
    }
    
    /**
     * 获取文章评论列表
     */
    @GetMapping("/article/{articleId}")
    public ResponseEntity<List<Comment>> getArticleComments(@PathVariable Long articleId) {
        // 检查文章是否存在
        if (!articleService.findById(articleId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "文章不存在");
        }
        
        List<Comment> comments = commentService.findByArticleId(articleId);
        return ResponseEntity.ok(comments);
    }
    
    /**
     * 获取帖子评论列表
     */
    @GetMapping("/post/{postId}")
    public ResponseEntity<List<Comment>> getPostComments(@PathVariable Long postId) {
        // 检查帖子是否存在
        if (!postService.findById(postId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "帖子不存在");
        }
        
        List<Comment> comments = commentService.findByPostId(postId);
        return ResponseEntity.ok(comments);
    }
    
    /**
     * 获取用户评论列表
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<Page<Comment>> getUserComments(
            @PathVariable Long userId,
            @PageableDefault(size = 10, sort = "createTime", direction = Sort.Direction.DESC) Pageable pageable) {
        
        // 检查用户是否存在
        if (!userService.findById(userId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "用户不存在");
        }
        
        Page<Comment> comments = commentService.findByUserId(userId, pageable);
        return ResponseEntity.ok(comments);
    }
    
    /**
     * 更新评论
     */
    @PutMapping("/{id}")
    public ResponseEntity<Comment> updateComment(
            @PathVariable Long id,
            @RequestParam String content) {
        
        try {
            Optional<Comment> commentOpt = commentService.findById(id);
            if (!commentOpt.isPresent()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "评论不存在");
            }
            
            Comment comment = commentOpt.get();
            comment.setContent(content);
            
            Comment updatedComment = commentService.save(comment);
            return ResponseEntity.ok(updatedComment);
            
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "更新评论失败: " + e.getMessage());
        }
    }
    
    /**
     * 逻辑删除评论
     */
    @DeleteMapping("/{id}/soft")
    public ResponseEntity<Comment> softDeleteComment(@PathVariable Long id) {
        try {
            if (!commentService.findById(id).isPresent()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "评论不存在");
            }
            
            Comment deletedComment = commentService.deleteComment(id);
            return ResponseEntity.ok(deletedComment);
            
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "删除评论失败: " + e.getMessage());
        }
    }
    
    /**
     * 物理删除评论
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteComment(@PathVariable Long id) {
        try {
            if (!commentService.findById(id).isPresent()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "评论不存在");
            }
            
            commentService.deleteById(id);
            return ResponseEntity.noContent().build();
            
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "删除评论失败: " + e.getMessage());
        }
    }
    
    /**
     * 点赞评论
     */
    @PostMapping("/{id}/like")
    public ResponseEntity<Comment> likeComment(@PathVariable Long id) {
        try {
            if (!commentService.findById(id).isPresent()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "评论不存在");
            }
            
            Comment likedComment = commentService.incrementLikeCount(id);
            return ResponseEntity.ok(likedComment);
            
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "点赞评论失败: " + e.getMessage());
        }
    }
    
    /**
     * 取消点赞评论
     */
    @PostMapping("/{id}/unlike")
    public ResponseEntity<Comment> unlikeComment(@PathVariable Long id) {
        try {
            if (!commentService.findById(id).isPresent()) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "评论不存在");
            }
            
            Comment unlikedComment = commentService.decrementLikeCount(id);
            return ResponseEntity.ok(unlikedComment);
            
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "取消点赞评论失败: " + e.getMessage());
        }
    }
}