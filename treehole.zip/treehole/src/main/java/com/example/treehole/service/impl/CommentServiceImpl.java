package com.example.treehole.service.impl;

import com.example.treehole.model.entity.Comment;
import com.example.treehole.repository.CommentRepository;
import com.example.treehole.service.CommentService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CommentServiceImpl implements CommentService {
    
    private final CommentRepository commentRepository;
    
    @Override
    @Transactional
    public Comment save(Comment comment) {
        if (comment.getId() == null) {
            // 新评论
            LocalDateTime now = LocalDateTime.now();
            comment.setCreateTime(now);
            comment.setUpdateTime(now);
            comment.setLikeCount(0);
            comment.setIsDeleted(false);
        } else {
            // 更新评论
            comment.setUpdateTime(LocalDateTime.now());
        }
        return commentRepository.save(comment);
    }
    
    @Override
    public Optional<Comment> findById(Long id) {
        return commentRepository.findById(id);
    }
    
    @Override
    public List<Comment> findByPostId(Long postId) {
        return commentRepository.findByPostIdOrderByCreateTimeAsc(postId);
    }
    
    @Override
    public List<Comment> findByArticleId(Long articleId) {
        return commentRepository.findByArticleIdOrderByCreateTimeAsc(articleId);
    }
    
    @Override
    public Page<Comment> findByUserId(Long userId, Pageable pageable) {
        return commentRepository.findByUserId(userId, pageable);
    }
    
    @Override
    public int countByPostId(Long postId) {
        return commentRepository.countByPostId(postId);
    }
    
    @Override
    public int countByArticleId(Long articleId) {
        return commentRepository.countByArticleId(articleId);
    }
    
    @Override
    @Transactional
    public Comment deleteComment(Long id) {
        Optional<Comment> commentOpt = commentRepository.findById(id);
        if (commentOpt.isPresent()) {
            Comment comment = commentOpt.get();
            comment.setIsDeleted(true);
            comment.setUpdateTime(LocalDateTime.now());
            return commentRepository.save(comment);
        }
        return null;
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        commentRepository.deleteById(id);
    }
    
    @Override
    @Transactional
    public Comment incrementLikeCount(Long id) {
        Optional<Comment> commentOpt = commentRepository.findById(id);
        if (commentOpt.isPresent()) {
            Comment comment = commentOpt.get();
            comment.setLikeCount(comment.getLikeCount() + 1);
            return commentRepository.save(comment);
        }
        return null;
    }
    
    @Override
    @Transactional
    public Comment decrementLikeCount(Long id) {
        Optional<Comment> commentOpt = commentRepository.findById(id);
        if (commentOpt.isPresent()) {
            Comment comment = commentOpt.get();
            if (comment.getLikeCount() > 0) {
                comment.setLikeCount(comment.getLikeCount() - 1);
                return commentRepository.save(comment);
            }
            return comment;
        }
        return null;
    }
}