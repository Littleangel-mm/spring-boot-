package com.example.treehole.service;

import com.example.treehole.model.entity.Comment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface CommentService {
    
    /**
     * 保存评论（新增或更新）
     */
    Comment save(Comment comment);
    
    /**
     * 根据ID查找评论
     */
    Optional<Comment> findById(Long id);
    
    /**
     * 根据帖子ID查询评论列表（按创建时间升序）
     */
    List<Comment> findByPostId(Long postId);
    
    /**
     * 根据文章ID查询评论列表（按创建时间升序）
     */
    List<Comment> findByArticleId(Long articleId);
    
    /**
     * 根据用户ID分页查询评论
     */
    Page<Comment> findByUserId(Long userId, Pageable pageable);
    
    /**
     * 统计帖子评论数
     */
    int countByPostId(Long postId);
    
    /**
     * 统计文章评论数
     */
    int countByArticleId(Long articleId);
    
    /**
     * 逻辑删除评论
     */
    Comment deleteComment(Long id);
    
    /**
     * 物理删除评论
     */
    void deleteById(Long id);
    
    /**
     * 增加评论点赞数
     */
    Comment incrementLikeCount(Long id);
    
    /**
     * 减少评论点赞数
     */
    Comment decrementLikeCount(Long id);
}