package com.example.treehole.util;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * 分页工具类
 */
public class PageUtil {
    
    /**
     * 将列表转换为分页对象
     *
     * @param list     列表数据
     * @param pageable 分页参数
     * @param <T>      数据类型
     * @return 分页对象
     */
    public static <T> Page<T> toPage(List<T> list, Pageable pageable) {
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), list.size());
        
        if (start > list.size()) {
            start = 0;
            end = 0;
        }
        
        List<T> content = list.subList(start, end);
        return new PageImpl<>(content, pageable, list.size());
    }
}