package com.example.treehole.controller;

import com.example.treehole.model.entity.About;
import com.example.treehole.service.AboutService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/admin/about")
@RequiredArgsConstructor
public class AboutManagementController {

    private final AboutService aboutService;

    /**
     * 获取所有关于我们信息（分页）
     */
    @GetMapping
    public ResponseEntity<?> getAllAbout(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<About> aboutPage = aboutService.findAll(pageable);
            
            return ResponseEntity.ok(aboutPage);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取关于我们列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取关于我们详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getAboutDetail(@PathVariable Long id) {
        try {
            Optional<About> aboutOpt = aboutService.findById(id);
            if (aboutOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("关于我们信息不存在");
            }
            
            return ResponseEntity.ok(aboutOpt.get());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取关于我们详情失败: " + e.getMessage());
        }
    }

    /**
     * 创建关于我们信息
     */
    @PostMapping
    public ResponseEntity<?> createAbout(@RequestBody About about) {
        try {
            // 设置创建时间和更新时间
            LocalDateTime now = LocalDateTime.now();
            about.setCreateTime(now);
            about.setUpdateTime(now);
            
            About savedAbout = aboutService.save(about);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedAbout);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("创建关于我们信息失败: " + e.getMessage());
        }
    }

    /**
     * 更新关于我们信息
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateAbout(@PathVariable Long id, @RequestBody About about) {
        try {
            Optional<About> existingAboutOpt = aboutService.findById(id);
            if (existingAboutOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("关于我们信息不存在");
            }
            
            About existingAbout = existingAboutOpt.get();
            
            // 更新字段
            existingAbout.setTitle(about.getTitle());
            existingAbout.setContent(about.getContent());
            existingAbout.setLogo(about.getLogo());
            existingAbout.setEmail(about.getEmail());
            existingAbout.setPhone(about.getPhone());
            existingAbout.setAddress(about.getAddress());
            existingAbout.setCopyright(about.getCopyright());
            existingAbout.setUpdateTime(LocalDateTime.now());
            
            About updatedAbout = aboutService.save(existingAbout);
            return ResponseEntity.ok(updatedAbout);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新关于我们信息失败: " + e.getMessage());
        }
    }

    /**
     * 删除关于我们信息
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAbout(@PathVariable Long id) {
        try {
            Optional<About> aboutOpt = aboutService.findById(id);
            if (aboutOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("关于我们信息不存在");
            }
            
            aboutService.deleteById(id);
            return ResponseEntity.ok("关于我们信息删除成功");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("删除关于我们信息失败: " + e.getMessage());
        }
    }

    /**
     * 获取关于我们统计信息
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getAboutStatistics() {
        try {
            List<About> allAbout = aboutService.findAll();
            
            Map<String, Object> statistics = new HashMap<>();
            statistics.put("totalAbout", allAbout.size());
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取关于我们统计信息失败: " + e.getMessage());
        }
    }
}