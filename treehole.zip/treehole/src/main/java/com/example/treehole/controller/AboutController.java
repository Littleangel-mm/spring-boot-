package com.example.treehole.controller;

import com.example.treehole.model.entity.About;
import com.example.treehole.service.AboutService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/about")
@RequiredArgsConstructor
public class AboutController {

    private final AboutService aboutService;

    /**
     * 获取关于我们信息（取最新一条）
     */
    @GetMapping
    public ResponseEntity<?> getAboutInfo() {
        try {
            // 获取最新的一条关于我们信息
            List<About> aboutList = aboutService.findAll(PageRequest.of(0, 1, Sort.by("id").descending())).getContent();
            
            if (aboutList.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("关于我们信息不存在");
            }
            
            return ResponseEntity.ok(aboutList.get(0));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取关于我们信息失败: " + e.getMessage());
        }
    }
}