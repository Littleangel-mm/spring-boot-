package com.example.treehole.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "t_message")
public class Message {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;
    
    @Column(name = "is_public", nullable = false)
    private Boolean isPublic = true;
    
    @Column(name = "is_replied", nullable = false)
    private Boolean isReplied = false;
    
    @Column(columnDefinition = "TEXT")
    private String reply;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reply_user_id")
    private User replyUser;
    
    @Column(name = "reply_time")
    private LocalDateTime replyTime;
    
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;
}