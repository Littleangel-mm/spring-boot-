package com.example.treehole.service;

import com.example.treehole.model.entity.Article;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface ArticleService {
    
    Article save(Article article);
    
    Optional<Article> findById(Long id);
    
    Page<Article> findAll(Pageable pageable);
    
    Page<Article> findByCategoryId(Long categoryId, Pageable pageable);
    
    Page<Article> findByAuthorId(Long authorId, Pageable pageable);
    
    Page<Article> search(String keyword, Pageable pageable);
    
    List<Article> findTopViewed(int limit);
    
    void deleteById(Long id);
    
    Article incrementViewCount(Long id);
}