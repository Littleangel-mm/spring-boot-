package com.example.treehole.repository;

import com.example.treehole.model.entity.Article;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ArticleRepository extends JpaRepository<Article, Long> {
    
    Page<Article> findByCategoryId(Long categoryId, Pageable pageable);
    
    Page<Article> findByTitleContainingOrContentContaining(String title, String content, Pageable pageable);
    
    List<Article> findTop5ByOrderByViewCountDesc();
    
    Page<Article> findByAuthorId(Long authorId, Pageable pageable);
}