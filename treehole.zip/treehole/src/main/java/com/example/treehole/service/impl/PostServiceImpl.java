package com.example.treehole.service.impl;

import com.example.treehole.model.entity.Post;
import com.example.treehole.repository.PostRepository;
import com.example.treehole.service.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PostServiceImpl implements PostService {
    
    private final PostRepository postRepository;
    
    @Override
    @Transactional
    public Post save(Post post) {
        if (post.getId() == null) {
            // 新帖子
            LocalDateTime now = LocalDateTime.now();
            post.setCreateTime(now);
            post.setUpdateTime(now);
            post.setViewCount(0);
            post.setLikeCount(0);
            post.setCommentCount(0);
            post.setIsTop(false);
            post.setIsEssence(false);
            post.setStatus(true);
        } else {
            // 更新帖子
            post.setUpdateTime(LocalDateTime.now());
        }
        return postRepository.save(post);
    }
    
    @Override
    public Optional<Post> findById(Long id) {
        return postRepository.findById(id);
    }
    
    @Override
    public Page<Post> findAll(Pageable pageable) {
        return postRepository.findAll(pageable);
    }
    
    @Override
    public Page<Post> findByZoneId(Long zoneId, Pageable pageable) {
        return postRepository.findByZoneId(zoneId, pageable);
    }
    
    @Override
    public Page<Post> findByUserId(Long userId, Pageable pageable) {
        return postRepository.findByUserId(userId, pageable);
    }
    
    @Override
    public Page<Post> search(String keyword, Pageable pageable) {
        return postRepository.findByTitleContainingOrContentContaining(keyword, keyword, pageable);
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        postRepository.deleteById(id);
    }
    
    @Override
    @Transactional
    public Post incrementViewCount(Long id) {
        Optional<Post> postOpt = postRepository.findById(id);
        if (postOpt.isPresent()) {
            Post post = postOpt.get();
            post.setViewCount(post.getViewCount() + 1);
            return postRepository.save(post);
        }
        return null;
    }
    
    @Override
    @Transactional
    public Post setTop(Long id, Boolean isTop) {
        Optional<Post> postOpt = postRepository.findById(id);
        if (postOpt.isPresent()) {
            Post post = postOpt.get();
            post.setIsTop(isTop);
            post.setUpdateTime(LocalDateTime.now());
            return postRepository.save(post);
        }
        return null;
    }
    
    @Override
    @Transactional
    public Post setEssence(Long id, Boolean isEssence) {
        Optional<Post> postOpt = postRepository.findById(id);
        if (postOpt.isPresent()) {
            Post post = postOpt.get();
            post.setIsEssence(isEssence);
            post.setUpdateTime(LocalDateTime.now());
            return postRepository.save(post);
        }
        return null;
    }
}