package com.example.treehole.service.impl;

import com.example.treehole.model.entity.Consultation;
import com.example.treehole.repository.ConsultationRepository;
import com.example.treehole.service.ConsultationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ConsultationServiceImpl implements ConsultationService {
    
    private final ConsultationRepository consultationRepository;
    
    @Override
    @Transactional
    public Consultation save(Consultation consultation) {
        if (consultation.getId() == null) {
            // 新咨询会话
            LocalDateTime now = LocalDateTime.now();
            consultation.setCreateTime(now);
            consultation.setUpdateTime(now);
            consultation.setStatus("ONGOING");
        } else {
            // 更新咨询会话
            consultation.setUpdateTime(LocalDateTime.now());
        }
        return consultationRepository.save(consultation);
    }
    
    @Override
    public Optional<Consultation> findById(Long id) {
        return consultationRepository.findById(id);
    }
    
    @Override
    public Page<Consultation> findAll(Pageable pageable) {
        return consultationRepository.findAll(pageable);
    }
    
    @Override
    public Page<Consultation> findByStudentId(Long studentId, Pageable pageable) {
        return consultationRepository.findByStudentId(studentId, pageable);
    }
    
    @Override
    public Page<Consultation> findByTeacherId(Long teacherId, Pageable pageable) {
        return consultationRepository.findByTeacherId(teacherId, pageable);
    }
    
    @Override
    @Transactional
    public Consultation closeConsultation(Long id) {
        Optional<Consultation> consultationOpt = consultationRepository.findById(id);
        if (consultationOpt.isPresent()) {
            Consultation consultation = consultationOpt.get();
            consultation.setStatus("CLOSED");
            consultation.setCloseTime(LocalDateTime.now());
            consultation.setUpdateTime(LocalDateTime.now());
            return consultationRepository.save(consultation);
        }
        return null;
    }
    
    @Override
    @Transactional
    public Consultation updateStatus(Long id, String status) {
        Optional<Consultation> consultationOpt = consultationRepository.findById(id);
        if (consultationOpt.isPresent()) {
            Consultation consultation = consultationOpt.get();
            consultation.setStatus(status);
            consultation.setUpdateTime(LocalDateTime.now());
            if ("CLOSED".equals(status)) {
                consultation.setCloseTime(LocalDateTime.now());
            }
            return consultationRepository.save(consultation);
        }
        return null;
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        consultationRepository.deleteById(id);
    }
}