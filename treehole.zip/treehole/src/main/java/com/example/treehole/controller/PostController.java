package com.example.treehole.controller;

import com.example.treehole.model.entity.Post;
import com.example.treehole.model.entity.User;
import com.example.treehole.model.entity.Zone;
import com.example.treehole.service.PostService;
import com.example.treehole.service.UserService;
import com.example.treehole.service.ZoneService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/posts")
@RequiredArgsConstructor
public class PostController {

    private final PostService postService;
    private final UserService userService;
    private final ZoneService zoneService;

    /**
     * 创建新帖子
     */
    @PostMapping
    public ResponseEntity<?> createPost(@RequestBody Post post, @RequestParam Long userId, @RequestParam Long zoneId) {
        try {
            // 验证用户是否存在
            Optional<User> userOpt = userService.findById(userId);
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("用户不存在");
            }
            
            // 验证分区是否存在
            Optional<Zone> zoneOpt = zoneService.findById(zoneId);
            if (zoneOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("分区不存在");
            }
            
            // 设置用户和分区
            post.setUser(userOpt.get());
            post.setZone(zoneOpt.get());
            
            // 保存帖子
            Post savedPost = postService.save(post);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedPost);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("创建帖子失败: " + e.getMessage());
        }
    }

    /**
     * 获取帖子详情（并增加浏览量）
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getPost(@PathVariable Long id) {
        try {
            Optional<Post> postOpt = postService.findById(id);
            if (postOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("帖子不存在");
            }
            
            // 增加浏览量
            Post post = postService.incrementViewCount(id);
            return ResponseEntity.ok(post);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取帖子失败: " + e.getMessage());
        }
    }

    /**
     * 更新帖子
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updatePost(@PathVariable Long id, @RequestBody Post updatedPost) {
        try {
            Optional<Post> postOpt = postService.findById(id);
            if (postOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("帖子不存在");
            }
            
            Post existingPost = postOpt.get();
            
            // 更新可修改的字段
            if (updatedPost.getTitle() != null) {
                existingPost.setTitle(updatedPost.getTitle());
            }
            if (updatedPost.getContent() != null) {
                existingPost.setContent(updatedPost.getContent());
            }
            if (updatedPost.getIsAnonymous() != null) {
                existingPost.setIsAnonymous(updatedPost.getIsAnonymous());
            }
            
            // 保存更新后的帖子
            Post savedPost = postService.save(existingPost);
            return ResponseEntity.ok(savedPost);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("更新帖子失败: " + e.getMessage());
        }
    }

    /**
     * 删除帖子
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePost(@PathVariable Long id) {
        try {
            Optional<Post> postOpt = postService.findById(id);
            if (postOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("帖子不存在");
            }
            
            postService.deleteById(id);
            return ResponseEntity.ok("帖子已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("删除帖子失败: " + e.getMessage());
        }
    }

    /**
     * 获取所有帖子（分页）
     */
    @GetMapping
    public ResponseEntity<?> getAllPosts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Post> posts = postService.findAll(pageable);
            
            return ResponseEntity.ok(posts);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取帖子列表失败: " + e.getMessage());
        }
    }

    /**
     * 根据分区ID获取帖子（分页）
     */
    @GetMapping("/zone/{zoneId}")
    public ResponseEntity<?> getPostsByZone(
            @PathVariable Long zoneId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Post> posts = postService.findByZoneId(zoneId, pageable);
            
            return ResponseEntity.ok(posts);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取分区帖子失败: " + e.getMessage());
        }
    }

    /**
     * 根据用户ID获取帖子（分页）
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getPostsByUser(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Post> posts = postService.findByUserId(userId, pageable);
            
            return ResponseEntity.ok(posts);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取用户帖子失败: " + e.getMessage());
        }
    }

    /**
     * 搜索帖子（分页）
     */
    @GetMapping("/search")
    public ResponseEntity<?> searchPosts(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Post> posts = postService.search(keyword, pageable);
            
            return ResponseEntity.ok(posts);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("搜索帖子失败: " + e.getMessage());
        }
    }

    /**
     * 设置帖子置顶状态
     */
    @PutMapping("/{id}/top")
    public ResponseEntity<?> setPostTop(@PathVariable Long id, @RequestParam Boolean isTop) {
        try {
            Optional<Post> postOpt = postService.findById(id);
            if (postOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("帖子不存在");
            }
            
            Post post = postService.setTop(id, isTop);
            return ResponseEntity.ok(post);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("设置帖子置顶状态失败: " + e.getMessage());
        }
    }

    /**
     * 设置帖子精华状态
     */
    @PutMapping("/{id}/essence")
    public ResponseEntity<?> setPostEssence(@PathVariable Long id, @RequestParam Boolean isEssence) {
        try {
            Optional<Post> postOpt = postService.findById(id);
            if (postOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("帖子不存在");
            }
            
            Post post = postService.setEssence(id, isEssence);
            return ResponseEntity.ok(post);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("设置帖子精华状态失败: " + e.getMessage());
        }
    }
}