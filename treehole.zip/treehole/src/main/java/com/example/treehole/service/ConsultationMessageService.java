package com.example.treehole.service;

import com.example.treehole.model.entity.ConsultationMessage;

import java.util.List;
import java.util.Optional;

public interface ConsultationMessageService {
    
    /**
     * 保存咨询消息
     */
    ConsultationMessage save(ConsultationMessage message);
    
    /**
     * 根据ID查找咨询消息
     */
    Optional<ConsultationMessage> findById(Long id);
    
    /**
     * 根据咨询会话ID查找所有消息
     */
    List<ConsultationMessage> findByConsultationId(Long consultationId);
    
    /**
     * 标记消息为已读
     */
    ConsultationMessage markAsRead(Long id);
    
    /**
     * 删除咨询消息
     */
    void deleteById(Long id);
}