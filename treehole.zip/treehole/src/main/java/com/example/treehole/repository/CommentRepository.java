package com.example.treehole.repository;

import com.example.treehole.model.entity.Comment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {
    
    List<Comment> findByPostIdOrderByCreateTimeAsc(Long postId);
    
    List<Comment> findByArticleIdOrderByCreateTimeAsc(Long articleId);
    
    Page<Comment> findByUserId(Long userId, Pageable pageable);
    
    int countByPostId(Long postId);
    
    int countByArticleId(Long articleId);
}