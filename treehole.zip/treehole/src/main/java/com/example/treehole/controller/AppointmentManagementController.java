package com.example.treehole.controller;

import com.example.treehole.model.entity.Appointment;
import com.example.treehole.model.entity.User;
import com.example.treehole.service.AppointmentService;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/admin/appointments")
@RequiredArgsConstructor
public class AppointmentManagementController {

    private final AppointmentService appointmentService;
    private final UserService userService;

    /**
     * 获取所有预约信息（分页）
     */
    @GetMapping
    public ResponseEntity<?> getAllAppointments(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "appointmentTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Appointment> appointments = appointmentService.findAll(pageable);
            
            return ResponseEntity.ok(appointments);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取预约列表失败: " + e.getMessage());
        }
    }

    /**
     * 根据状态获取预约信息（分页）
     */
    @GetMapping("/status/{status}")
    public ResponseEntity<?> getAppointmentsByStatus(
            @PathVariable String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "appointmentTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Appointment> appointments = appointmentService.findByStatus(status, pageable);
            
            return ResponseEntity.ok(appointments);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取预约列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取预约详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getAppointmentById(@PathVariable Long id) {
        try {
            Optional<Appointment> appointmentOpt = appointmentService.findById(id);
            if (appointmentOpt.isPresent()) {
                return ResponseEntity.ok(appointmentOpt.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("预约不存在");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取预约详情失败: " + e.getMessage());
        }
    }

    /**
     * 创建预约
     */
    @PostMapping
    public ResponseEntity<?> createAppointment(
            @RequestBody Appointment appointment,
            @RequestParam Long studentId,
            @RequestParam Long teacherId) {
        try {
            // 验证学生是否存在
            Optional<User> studentOpt = userService.findById(studentId);
            if (studentOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("学生不存在");
            }
            
            // 验证教师是否存在
            Optional<User> teacherOpt = userService.findById(teacherId);
            if (teacherOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("教师不存在");
            }
            
            // 检查教师在该时间段是否已有预约
            LocalDateTime appointmentTime = appointment.getAppointmentTime();
            LocalDateTime endTime = appointmentTime.plusMinutes(appointment.getDuration());
            List<Appointment> existingAppointments = appointmentService.findByTeacherIdAndTimeBetween(
                    teacherId, appointmentTime, endTime);
            
            if (!existingAppointments.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("该时间段教师已有预约");
            }
            
            // 设置学生和教师
            appointment.setStudent(studentOpt.get());
            appointment.setTeacher(teacherOpt.get());
            
            // 保存预约
            Appointment savedAppointment = appointmentService.save(appointment);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedAppointment);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("创建预约失败: " + e.getMessage());
        }
    }

    /**
     * 更新预约状态
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateAppointmentStatus(
            @PathVariable Long id,
            @RequestParam String status,
            @RequestParam(required = false) String cancelReason) {
        try {
            Optional<Appointment> appointmentOpt = appointmentService.findById(id);
            if (appointmentOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("预约不存在");
            }
            
            // 验证状态值是否有效
            if (!isValidStatus(status)) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("无效的状态值");
            }
            
            // 如果是取消状态，必须提供取消原因
            if ("CANCELLED".equals(status) && (cancelReason == null || cancelReason.trim().isEmpty())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("取消预约必须提供取消原因");
            }
            
            Appointment updatedAppointment = appointmentService.updateStatus(id, status, cancelReason);
            return ResponseEntity.ok(updatedAppointment);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新预约状态失败: " + e.getMessage());
        }
    }

    /**
     * 删除预约
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAppointment(@PathVariable Long id) {
        try {
            Optional<Appointment> appointmentOpt = appointmentService.findById(id);
            if (appointmentOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("预约不存在");
            }
            
            appointmentService.deleteById(id);
            return ResponseEntity.ok("预约已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("删除预约失败: " + e.getMessage());
        }
    }

    /**
     * 获取教师在指定时间范围内的预约
     */
    @GetMapping("/teacher/{teacherId}/schedule")
    public ResponseEntity<?> getTeacherSchedule(
            @PathVariable Long teacherId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end) {
        try {
            // 验证教师是否存在
            Optional<User> teacherOpt = userService.findById(teacherId);
            if (teacherOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("教师不存在");
            }
            
            List<Appointment> appointments = appointmentService.findByTeacherIdAndTimeBetween(
                    teacherId, start, end);
            return ResponseEntity.ok(appointments);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取教师日程失败: " + e.getMessage());
        }
    }

    /**
     * 获取预约统计信息
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getAppointmentStatistics() {
        try {
            Pageable pageable = PageRequest.of(0, 1);
            
            // 获取总预约数
            Page<Appointment> allAppointments = appointmentService.findAll(pageable);
            long totalAppointments = allAppointments.getTotalElements();
            
            // 获取待处理预约数
            Page<Appointment> pendingAppointments = appointmentService.findByStatus("PENDING", pageable);
            long pendingCount = pendingAppointments.getTotalElements();
            
            // 获取已确认预约数
            Page<Appointment> confirmedAppointments = appointmentService.findByStatus("CONFIRMED", pageable);
            long confirmedCount = confirmedAppointments.getTotalElements();
            
            // 获取已完成预约数
            Page<Appointment> completedAppointments = appointmentService.findByStatus("COMPLETED", pageable);
            long completedCount = completedAppointments.getTotalElements();
            
            // 获取已取消预约数
            Page<Appointment> cancelledAppointments = appointmentService.findByStatus("CANCELLED", pageable);
            long cancelledCount = cancelledAppointments.getTotalElements();
            
            Map<String, Object> statistics = new HashMap<>();
            statistics.put("totalAppointments", totalAppointments);
            statistics.put("pendingCount", pendingCount);
            statistics.put("confirmedCount", confirmedCount);
            statistics.put("completedCount", completedCount);
            statistics.put("cancelledCount", cancelledCount);
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取预约统计信息失败: " + e.getMessage());
        }
    }

    /**
     * 验证状态值是否有效
     */
    private boolean isValidStatus(String status) {
        return "PENDING".equals(status) || 
               "CONFIRMED".equals(status) || 
               "COMPLETED".equals(status) || 
               "CANCELLED".equals(status);
    }
}