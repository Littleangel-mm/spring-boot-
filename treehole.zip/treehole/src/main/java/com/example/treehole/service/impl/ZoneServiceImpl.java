package com.example.treehole.service.impl;

import com.example.treehole.model.entity.Zone;
import com.example.treehole.repository.ZoneRepository;
import com.example.treehole.service.ZoneService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ZoneServiceImpl implements ZoneService {
    
    private final ZoneRepository zoneRepository;
    
    @Override
    @Transactional
    public Zone save(Zone zone) {
        return zoneRepository.save(zone);
    }
    
    @Override
    public Optional<Zone> findById(Long id) {
        return zoneRepository.findById(id);
    }
    
    @Override
    public List<Zone> findAll() {
        return zoneRepository.findAll();
    }
    
    @Override
    public List<Zone> findAllSorted() {
        return zoneRepository.findByOrderBySortAsc();
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        zoneRepository.deleteById(id);
    }
    
    @Override
    public boolean existsByName(String name) {
        return zoneRepository.existsByName(name);
    }
}