package com.example.treehole.service.impl;

import com.example.treehole.model.entity.UserFavorite;
import com.example.treehole.repository.UserFavoriteRepository;
import com.example.treehole.service.UserFavoriteService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserFavoriteServiceImpl implements UserFavoriteService {
    
    private final UserFavoriteRepository userFavoriteRepository;
    
    @Override
    @Transactional
    public UserFavorite addFavorite(UserFavorite userFavorite) {
        // 设置创建时间
        userFavorite.setCreateTime(LocalDateTime.now());
        return userFavoriteRepository.save(userFavorite);
    }
    
    @Override
    public Optional<UserFavorite> findById(Long id) {
        return userFavoriteRepository.findById(id);
    }
    
    @Override
    public Page<UserFavorite> findByUserId(Long userId, Pageable pageable) {
        return userFavoriteRepository.findByUserId(userId, pageable);
    }
    
    @Override
    public boolean existsByUserIdAndArticleId(Long userId, Long articleId) {
        return userFavoriteRepository.existsByUserIdAndArticleId(userId, articleId);
    }
    
    @Override
    public boolean existsByUserIdAndPostId(Long userId, Long postId) {
        // 需要在UserFavoriteRepository中添加此方法
        return userFavoriteRepository.existsByUserIdAndPostId(userId, postId);
    }
    
    @Override
    public boolean existsByUserIdAndPsychInfoId(Long userId, Long psychInfoId) {
        // 需要在UserFavoriteRepository中添加此方法
        return userFavoriteRepository.existsByUserIdAndPsychInfoId(userId, psychInfoId);
    }
    
    @Override
    public Optional<UserFavorite> findByUserIdAndArticleId(Long userId, Long articleId) {
        return userFavoriteRepository.findByUserIdAndArticleId(userId, articleId);
    }
    
    @Override
    public Optional<UserFavorite> findByUserIdAndPostId(Long userId, Long postId) {
        // 需要在UserFavoriteRepository中添加此方法
        return userFavoriteRepository.findByUserIdAndPostId(userId, postId);
    }
    
    @Override
    public Optional<UserFavorite> findByUserIdAndPsychInfoId(Long userId, Long psychInfoId) {
        // 需要在UserFavoriteRepository中添加此方法
        return userFavoriteRepository.findByUserIdAndPsychInfoId(userId, psychInfoId);
    }
    
    @Override
    @Transactional
    public void removeArticleFavorite(Long userId, Long articleId) {
        userFavoriteRepository.deleteByUserIdAndArticleId(userId, articleId);
    }
    
    @Override
    @Transactional
    public void removePostFavorite(Long userId, Long postId) {
        // 需要在UserFavoriteRepository中添加此方法
        userFavoriteRepository.deleteByUserIdAndPostId(userId, postId);
    }
    
    @Override
    @Transactional
    public void removePsychInfoFavorite(Long userId, Long psychInfoId) {
        // 需要在UserFavoriteRepository中添加此方法
        userFavoriteRepository.deleteByUserIdAndPsychInfoId(userId, psychInfoId);
    }
    
    @Override
    @Transactional
    public void deleteById(Long id) {
        userFavoriteRepository.deleteById(id);
    }
}