package com.example.treehole.controller;

import com.example.treehole.service.SystemConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/system")
@RequiredArgsConstructor
public class SystemConfigController {

    private final SystemConfigService systemConfigService;

    /**
     * 获取所有启用的系统配置
     */
    @GetMapping("/configs")
    public ResponseEntity<?> getAllEnabledConfigs() {
        try {
            Map<String, String> configMap = systemConfigService.getAllConfigMap();
            return ResponseEntity.ok(configMap);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取系统配置失败: " + e.getMessage());
        }
    }

    /**
     * 根据配置键获取系统配置值
     */
    @GetMapping("/configs/{configKey}")
    public ResponseEntity<?> getConfigValueByKey(@PathVariable String configKey) {
        try {
            return systemConfigService.findByConfigKey(configKey)
                    .map(config -> {
                        if (config.getEnabled()) {
                            return ResponseEntity.ok(config.getConfigValue());
                        } else {
                            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("配置未启用");
                        }
                    })
                    .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body("配置不存在"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取系统配置失败: " + e.getMessage());
        }
    }
}