package com.example.treehole.service;

import com.example.treehole.model.entity.SystemConfig;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface SystemConfigService {
    
    /**
     * 保存系统配置（新增或更新）
     */
    SystemConfig save(SystemConfig systemConfig);
    
    /**
     * 根据ID查找系统配置
     */
    Optional<SystemConfig> findById(Long id);
    
    /**
     * 根据配置键查找系统配置
     */
    Optional<SystemConfig> findByConfigKey(String configKey);
    
    /**
     * 分页查询所有系统配置
     */
    Page<SystemConfig> findAll(Pageable pageable);
    
    /**
     * 查询所有启用的系统配置
     */
    List<SystemConfig> findAllEnabled();
    
    /**
     * 获取所有启用的系统配置（以Map形式返回）
     */
    Map<String, String> getAllConfigMap();
    
    /**
     * 根据ID删除系统配置
     */
    void deleteById(Long id);
    
    /**
     * 更新系统配置状态（启用/禁用）
     */
    SystemConfig updateStatus(Long id, Boolean enabled);
    
    /**
     * 批量更新系统配置
     */
    List<SystemConfig> batchUpdate(Map<String, String> configMap);
}