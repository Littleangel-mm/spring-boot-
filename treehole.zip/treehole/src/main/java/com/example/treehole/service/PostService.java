package com.example.treehole.service;

import com.example.treehole.model.entity.Post;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

public interface PostService {
    
    /**
     * 保存帖子（新增或更新）
     */
    Post save(Post post);
    
    /**
     * 根据ID查找帖子
     */
    Optional<Post> findById(Long id);
    
    /**
     * 分页查询所有帖子
     */
    Page<Post> findAll(Pageable pageable);
    
    /**
     * 根据分区ID查询帖子
     */
    Page<Post> findByZoneId(Long zoneId, Pageable pageable);
    
    /**
     * 根据用户ID查询帖子
     */
    Page<Post> findByUserId(Long userId, Pageable pageable);
    
    /**
     * 搜索帖子（标题或内容包含关键字）
     */
    Page<Post> search(String keyword, Pageable pageable);
    
    /**
     * 根据ID删除帖子
     */
    void deleteById(Long id);
    
    /**
     * 增加帖子浏览量
     */
    Post incrementViewCount(Long id);
    
    /**
     * 设置帖子置顶状态
     */
    Post setTop(Long id, Boolean isTop);
    
    /**
     * 设置帖子精华状态
     */
    Post setEssence(Long id, Boolean isEssence);
}