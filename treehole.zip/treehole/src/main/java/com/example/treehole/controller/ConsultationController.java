package com.example.treehole.controller;

import com.example.treehole.model.entity.Consultation;
import com.example.treehole.model.entity.ConsultationMessage;
import com.example.treehole.model.entity.User;
import com.example.treehole.service.ConsultationMessageService;
import com.example.treehole.service.ConsultationService;
import com.example.treehole.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/consultations")
@RequiredArgsConstructor
public class ConsultationController {

    private final ConsultationService consultationService;
    private final ConsultationMessageService consultationMessageService;
    private final UserService userService;

    /**
     * 创建新咨询会话
     */
    @PostMapping
    public ResponseEntity<?> createConsultation(
            @RequestBody Consultation consultation,
            @RequestParam Long studentId,
            @RequestParam Long teacherId) {
        try {
            // 验证学生是否存在
            Optional<User> studentOpt = userService.findById(studentId);
            if (studentOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("学生不存在");
            }
            
            // 验证教师是否存在
            Optional<User> teacherOpt = userService.findById(teacherId);
            if (teacherOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("教师不存在");
            }
            
            // 设置学生和教师
            consultation.setStudent(studentOpt.get());
            consultation.setTeacher(teacherOpt.get());
            
            // 保存咨询会话
            Consultation savedConsultation = consultationService.save(consultation);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedConsultation);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("创建咨询会话失败: " + e.getMessage());
        }
    }

    /**
     * 获取咨询会话详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getConsultation(@PathVariable Long id) {
        try {
            Optional<Consultation> consultationOpt = consultationService.findById(id);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            return ResponseEntity.ok(consultationOpt.get());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取咨询会话失败: " + e.getMessage());
        }
    }

    /**
     * 更新咨询会话
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateConsultation(@PathVariable Long id, @RequestBody Consultation updatedConsultation) {
        try {
            Optional<Consultation> consultationOpt = consultationService.findById(id);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            Consultation existingConsultation = consultationOpt.get();
            
            // 更新可修改的字段
            if (updatedConsultation.getTitle() != null) {
                existingConsultation.setTitle(updatedConsultation.getTitle());
            }
            
            // 保存更新后的咨询会话
            Consultation savedConsultation = consultationService.save(existingConsultation);
            return ResponseEntity.ok(savedConsultation);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("更新咨询会话失败: " + e.getMessage());
        }
    }

    /**
     * 关闭咨询会话
     */
    @PutMapping("/{id}/close")
    public ResponseEntity<?> closeConsultation(@PathVariable Long id) {
        try {
            Optional<Consultation> consultationOpt = consultationService.findById(id);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            Consultation closedConsultation = consultationService.closeConsultation(id);
            return ResponseEntity.ok(closedConsultation);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("关闭咨询会话失败: " + e.getMessage());
        }
    }

    /**
     * 更新咨询会话状态
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateConsultationStatus(@PathVariable Long id, @RequestParam String status) {
        try {
            Optional<Consultation> consultationOpt = consultationService.findById(id);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            Consultation updatedConsultation = consultationService.updateStatus(id, status);
            return ResponseEntity.ok(updatedConsultation);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("更新咨询会话状态失败: " + e.getMessage());
        }
    }

    /**
     * 删除咨询会话
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteConsultation(@PathVariable Long id) {
        try {
            Optional<Consultation> consultationOpt = consultationService.findById(id);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            consultationService.deleteById(id);
            return ResponseEntity.ok("咨询会话已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("删除咨询会话失败: " + e.getMessage());
        }
    }

    /**
     * 获取学生的咨询会话列表
     */
    @GetMapping("/student/{studentId}")
    public ResponseEntity<?> getConsultationsByStudentId(
            @PathVariable Long studentId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Consultation> consultations = consultationService.findByStudentId(studentId, pageable);
            
            return ResponseEntity.ok(consultations);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取学生咨询会话失败: " + e.getMessage());
        }
    }

    /**
     * 获取教师的咨询会话列表
     */
    @GetMapping("/teacher/{teacherId}")
    public ResponseEntity<?> getConsultationsByTeacherId(
            @PathVariable Long teacherId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Consultation> consultations = consultationService.findByTeacherId(teacherId, pageable);
            
            return ResponseEntity.ok(consultations);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取教师咨询会话失败: " + e.getMessage());
        }
    }

    /**
     * 获取所有咨询会话（分页）
     */
    @GetMapping
    public ResponseEntity<?> getAllConsultations(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createTime") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Consultation> consultations = consultationService.findAll(pageable);
            
            return ResponseEntity.ok(consultations);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取咨询会话列表失败: " + e.getMessage());
        }
    }

    /**
     * 发送咨询消息
     */
    @PostMapping("/{consultationId}/messages")
    public ResponseEntity<?> sendConsultationMessage(
            @PathVariable Long consultationId,
            @RequestBody ConsultationMessage message,
            @RequestParam Long senderId) {
        try {
            // 验证咨询会话是否存在
            Optional<Consultation> consultationOpt = consultationService.findById(consultationId);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("咨询会话不存在");
            }
            
            // 验证发送者是否存在
            Optional<User> senderOpt = userService.findById(senderId);
            if (senderOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("发送者不存在");
            }
            
            // 设置咨询会话和发送者
            message.setConsultation(consultationOpt.get());
            message.setSender(senderOpt.get());
            message.setCreateTime(LocalDateTime.now());
            message.setIsRead(false);
            
            // 保存咨询消息
            ConsultationMessage savedMessage = consultationMessageService.save(message);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedMessage);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("发送咨询消息失败: " + e.getMessage());
        }
    }

    /**
     * 获取咨询会话的所有消息
     */
    @GetMapping("/{consultationId}/messages")
    public ResponseEntity<?> getConsultationMessages(@PathVariable Long consultationId) {
        try {
            // 验证咨询会话是否存在
            Optional<Consultation> consultationOpt = consultationService.findById(consultationId);
            if (consultationOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("咨询会话不存在");
            }
            
            List<ConsultationMessage> messages = consultationMessageService.findByConsultationId(consultationId);
            return ResponseEntity.ok(messages);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("获取咨询消息失败: " + e.getMessage());
        }
    }

    /**
     * 标记消息为已读
     */
    @PutMapping("/messages/{messageId}/read")
    public ResponseEntity<?> markMessageAsRead(@PathVariable Long messageId) {
        try {
            Optional<ConsultationMessage> messageOpt = consultationMessageService.findById(messageId);
            if (messageOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("消息不存在");
            }
            
            ConsultationMessage updatedMessage = consultationMessageService.markAsRead(messageId);
            return ResponseEntity.ok(updatedMessage);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("标记消息为已读失败: " + e.getMessage());
        }
    }

    /**
     * 删除咨询消息
     */
    @DeleteMapping("/messages/{messageId}")
    public ResponseEntity<?> deleteConsultationMessage(@PathVariable Long messageId) {
        try {
            Optional<ConsultationMessage> messageOpt = consultationMessageService.findById(messageId);
            if (messageOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("消息不存在");
            }
            
            consultationMessageService.deleteById(messageId);
            return ResponseEntity.ok("消息已删除");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("删除消息失败: " + e.getMessage());
        }
    }
}