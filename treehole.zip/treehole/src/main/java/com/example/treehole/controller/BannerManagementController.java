package com.example.treehole.controller;

import com.example.treehole.model.entity.Banner;
import com.example.treehole.service.BannerService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/admin/banners")
@RequiredArgsConstructor
public class BannerManagementController {

    private final BannerService bannerService;

    /**
     * 获取所有Banner（分页）
     */
    @GetMapping
    public ResponseEntity<?> getAllBanners(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "sort") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {
        try {
            Sort sort = direction.equalsIgnoreCase("asc") ? 
                    Sort.by(sortBy).ascending() : 
                    Sort.by(sortBy).descending();
            
            Pageable pageable = PageRequest.of(page, size, sort);
            Page<Banner> banners = bannerService.findAll(pageable);
            
            return ResponseEntity.ok(banners);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取Banner列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取Banner详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getBannerDetail(@PathVariable Long id) {
        try {
            Optional<Banner> bannerOpt = bannerService.findById(id);
            if (bannerOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Banner不存在");
            }
            
            return ResponseEntity.ok(bannerOpt.get());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取Banner详情失败: " + e.getMessage());
        }
    }

    /**
     * 创建Banner
     */
    @PostMapping
    public ResponseEntity<?> createBanner(@RequestBody Banner banner) {
        try {
            // 设置创建时间和更新时间
            LocalDateTime now = LocalDateTime.now();
            banner.setCreateTime(now);
            banner.setUpdateTime(now);
            
            // 如果没有设置排序，默认为0
            if (banner.getSort() == null) {
                banner.setSort(0);
            }
            
            // 如果没有设置启用状态，默认为true
            if (banner.getEnabled() == null) {
                banner.setEnabled(true);
            }
            
            Banner savedBanner = bannerService.save(banner);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedBanner);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("创建Banner失败: " + e.getMessage());
        }
    }

    /**
     * 更新Banner
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBanner(@PathVariable Long id, @RequestBody Banner banner) {
        try {
            Optional<Banner> existingBannerOpt = bannerService.findById(id);
            if (existingBannerOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Banner不存在");
            }
            
            Banner existingBanner = existingBannerOpt.get();
            
            // 更新字段
            existingBanner.setTitle(banner.getTitle());
            existingBanner.setImageUrl(banner.getImageUrl());
            existingBanner.setLinkUrl(banner.getLinkUrl());
            existingBanner.setDescription(banner.getDescription());
            existingBanner.setSort(banner.getSort());
            existingBanner.setEnabled(banner.getEnabled());
            existingBanner.setUpdateTime(LocalDateTime.now());
            
            Banner updatedBanner = bannerService.save(existingBanner);
            return ResponseEntity.ok(updatedBanner);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新Banner失败: " + e.getMessage());
        }
    }

    /**
     * 删除Banner
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBanner(@PathVariable Long id) {
        try {
            Optional<Banner> bannerOpt = bannerService.findById(id);
            if (bannerOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Banner不存在");
            }
            
            bannerService.deleteById(id);
            return ResponseEntity.ok("Banner删除成功");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("删除Banner失败: " + e.getMessage());
        }
    }

    /**
     * 更新Banner状态（启用/禁用）
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateBannerStatus(
            @PathVariable Long id, 
            @RequestParam Boolean enabled) {
        try {
            Banner banner = bannerService.updateStatus(id, enabled);
            if (banner == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Banner不存在");
            }
            
            return ResponseEntity.ok(banner);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新Banner状态失败: " + e.getMessage());
        }
    }

    /**
     * 更新Banner排序
     */
    @PutMapping("/{id}/sort")
    public ResponseEntity<?> updateBannerSort(
            @PathVariable Long id, 
            @RequestParam Integer sort) {
        try {
            Banner banner = bannerService.updateSort(id, sort);
            if (banner == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Banner不存在");
            }
            
            return ResponseEntity.ok(banner);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("更新Banner排序失败: " + e.getMessage());
        }
    }

    /**
     * 获取所有启用的Banner（前台使用）
     */
    @GetMapping("/enabled")
    public ResponseEntity<?> getAllEnabledBanners() {
        try {
            List<Banner> banners = bannerService.findAllEnabledAndSorted();
            return ResponseEntity.ok(banners);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取启用的Banner列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取Banner统计信息
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getBannerStatistics() {
        try {
            Page<Banner> allBanners = bannerService.findAll(Pageable.unpaged());
            List<Banner> enabledBanners = bannerService.findAllEnabledAndSorted();
            
            Map<String, Object> statistics = new HashMap<>();
            statistics.put("totalBanners", allBanners.getTotalElements());
            statistics.put("enabledBanners", enabledBanners.size());
            statistics.put("disabledBanners", allBanners.getTotalElements() - enabledBanners.size());
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取Banner统计信息失败: " + e.getMessage());
        }
    }
}