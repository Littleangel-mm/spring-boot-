package com.example.treehole.service;

import com.example.treehole.model.entity.Zone;

import java.util.List;
import java.util.Optional;

public interface ZoneService {
    
    Zone save(Zone zone);
    
    Optional<Zone> findById(Long id);
    
    List<Zone> findAll();
    
    List<Zone> findAllSorted();
    
    void deleteById(Long id);
    
    boolean existsByName(String name);
}