package com.example.treehole.controller;

import com.example.treehole.model.entity.Banner;
import com.example.treehole.service.BannerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/banners")
@RequiredArgsConstructor
public class BannerController {

    private final BannerService bannerService;

    /**
     * 获取所有启用的Banner（按排序字段升序排列）
     */
    @GetMapping
    public ResponseEntity<?> getAllEnabledBanners() {
        try {
            List<Banner> banners = bannerService.findAllEnabledAndSorted();
            return ResponseEntity.ok(banners);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("获取Banner列表失败: " + e.getMessage());
        }
    }
}